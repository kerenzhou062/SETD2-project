setwd("H:/lab_data/project/SETD2/report/2017.4.23/RNA-seq")
rawdata <- read.delim("Hela_RNA-seq_shCont-shSetD2_htseq-count.txt",check.names=FALSE, stringsAsFactors=FALSE);
library(edgeR)
y <- DGEList(counts=rawdata[,2:ncol(rawdata)], genes=rawdata[,1])
Tissue <- factor(c("N","N","T","T"))
data.frame(Sample=colnames(y),Tissue)
design <- model.matrix(~Tissue)
rownames(design) <- colnames(y)
y <- estimateDisp(y, design, robust=TRUE)
#y$common.dispersion
#plotBCV(y)
fit <- glmFit(y, design)
lrt <- glmLRT(fit)
#topTags(lrt)
out <- topTags(lrt, n=Inf, adjust.method="BH")
write.table(out, file="Hela_RNA-seq_shCont-shSetD2_htseq-count.FC.txt", quote=FALSE, row.names=TRUE, col.names=TRUE, sep="\t")

rawdata <- read.delim("HepG2_RNA-seq_shCont-shSetD2_htseq-count.txt",check.names=FALSE, stringsAsFactors=FALSE);
library(edgeR)
y <- DGEList(counts=rawdata[,2:ncol(rawdata)], genes=rawdata[,1])
Tissue <- factor(c("N","N","T","T"))
data.frame(Sample=colnames(y),Tissue)
design <- model.matrix(~Tissue)
rownames(design) <- colnames(y)
y <- estimateDisp(y, design, robust=TRUE)
#y$common.dispersion
#plotBCV(y)
fit <- glmFit(y, design)
lrt <- glmLRT(fit)
#topTags(lrt)
out <- topTags(lrt, n=Inf, adjust.method="BH")
write.table(out, file="HepG2_RNA-seq_shCont-shSetD2_htseq-count.FC.txt", quote=FALSE, row.names=TRUE, col.names=TRUE, sep="\t")

