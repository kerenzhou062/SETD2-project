
library("VennDiagram")
library("grid")

setwd("H:/lab_data/project/SETD2/report/2017.6.2/chip-seq/Hela/venn")
shCont_peak <- read.table("Hela_macs_shCont_peaks_name.txt",sep="\t",header = FALSE, stringsAsFactors=TRUE)
shSetD2_peak <- read.table("Hela_macs_shSetD2_peaks_name.txt",sep="\t",header = FALSE, stringsAsFactors=TRUE)

shCont_peak <- shCont_peak[,1]
shSetD2_peak <- shSetD2_peak[,1]

venn.diagram(x= list(shSETD2 = shSetD2_peak,shNC = shCont_peak ), filename = "Hela_venn.tiff",resolution = 300,
  imagetype="tiff", fill=c("yellow", "green"), cat.col=c("black", "black"),
  scaled = FALSE, cat.default.pos = "text",
  fontface = "bold", alpha = 0.5, cex=1.2, cat.cex=1.6)

