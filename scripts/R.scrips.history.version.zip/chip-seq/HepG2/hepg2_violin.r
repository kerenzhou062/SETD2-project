
library("reshape2")
library("ggplot2")
setwd("H:/lab_data/project/SETD2/report/2017.5.4/chip-seq/HepG2/violinPlot");
myData <- read.table("HepG2_chip-seq_enrichment.txt", header = TRUE, sep="\t")

pValFunction <- function(pval) {
  if (pval == 0) {
    return ("<2.22e-308")
  }else if (pval == 1) {
    return ("=1")
  }else{
    exactVal = sprintf("%.2e", pval)
    exactVal = paste("=", exactVal, sep = "")
    return (exactVal)
  }
}

wilcoxTest <- wilcox.test(myData$shCont,myData$shSetD2, alternative="greater", paired = FALSE, exact = TRUE, correct = TRUE)
pvalue = pValFunction(wilcoxTest$p.value)

reshapeData <- melt(myData[1:2])
levels(reshapeData$variable)[levels(reshapeData$variable)=="shCont"] <- "shNC"
levels(reshapeData$variable)[levels(reshapeData$variable)=="shSetD2"] <- "shSETD2"

HepG2_violin_foldEnrichment <- ggplot(reshapeData, aes(x=variable, y=value, fill=variable)) +
    geom_violin(trim=FALSE) + labs(title="",x="", y = paste("Fold Enrichment of H3K36me3 sites (p-value", pvalue, ")"))
HepG2_violin_foldEnrichment <- HepG2_violin_foldEnrichment + stat_summary(fun.y=median, geom="point", size=2, color="red")
HepG2_violin_foldEnrichment <- HepG2_violin_foldEnrichment + theme(legend.position="none")
pdf("HepG2_violin_foldEnrichment.pdf")
plot(HepG2_violin_foldEnrichment)
dev.off()

wilcoxTest <- wilcox.test(myData$shContLog2,myData$shSetD2Log2, alternative="greater", paired = FALSE, exact = TRUE, correct = TRUE)
pvalue = pValFunction(wilcoxTest$p.value)

reshapeData <- melt(myData[3:4])
levels(reshapeData$variable)[levels(reshapeData$variable)=="shContLog2"] <- "shNC"
levels(reshapeData$variable)[levels(reshapeData$variable)=="shSetD2Log2"] <- "shSETD2"


HepG2_violin_foldEnrichment_log2 <- ggplot(reshapeData, aes(x=variable, y=value, fill=variable)) +
    geom_violin(trim=FALSE) + labs(title="",x="", y = paste("Fold Enrichment(log2) of H3K36me3 sites (p-value", pvalue, ")"))
HepG2_violin_foldEnrichment_log2 <- HepG2_violin_foldEnrichment_log2 + stat_summary(fun.y=median, geom="point", size=2, color="red")
HepG2_violin_foldEnrichment_log2 <- HepG2_violin_foldEnrichment_log2 + theme(legend.position="none")
pdf("HepG2_violin_foldEnrichment_log2.pdf")
plot(HepG2_violin_foldEnrichment_log2)
dev.off()

