
library("VennDiagram")
library("grid")

setwd("H:/lab_data/project/SETD2/report/2017.11.7/m6a-seq/Hela/venn")
shSetD2_gene <- read.table("Hela_shSetD2_-F0.5_FC_gene.txt",sep="\t",header = FALSE, stringsAsFactors=TRUE)
shM14_gene <- read.table("Hela_shM14_-F0.5_FC_gene.txt",sep="\t",header = FALSE, stringsAsFactors=TRUE)
shM3_gene <- read.table("Hela_shM3_-F0.5_FC_gene.txt",sep="\t",header = FALSE, stringsAsFactors=TRUE)
shWTAP_gene <- read.table("Hela_shWTAP_-F0.5_FC_gene.txt",sep="\t",header = FALSE, stringsAsFactors=TRUE)

shSetD2_gene <- shSetD2_gene[,1]
shM14_gene <- shM14_gene[,1]
shM3_gene <- shM3_gene[,1]
shWTAP_gene <- shWTAP_gene[,1]

venn.diagram(x= list(shSETD2 = shSetD2_gene,shMETTL14 = shM14_gene,shMETTL3 = shM3_gene,shWTAP = shWTAP_gene), filename = "Hela_venn.tiff",resolution = 300,
  imagetype="tiff", col="transparent", fill=c("cornflowerblue","seagreen3","darkorange1","darkorchid1"), cat.col=c("cornflowerblue","seagreen3","darkorange1","darkorchid1"),
  fontface = "bold", alpha = 0.5, cex=1.2, cat.cex=1.2)

