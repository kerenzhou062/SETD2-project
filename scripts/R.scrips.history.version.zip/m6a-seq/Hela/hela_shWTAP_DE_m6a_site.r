#!/public/zhoukr/softwares/R/bin/Rscript
library("exomePeak")

setwd("/data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela")
dir.create("./shWTAP")
setwd("./shWTAP")

gtf = "/data/zhoukr/reference/genome/gtf/gencode.v24lift37.annotation.gtf"
f1 = "/data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shCont/Hela_m6A-seq_shCont_IP.sorted.bam"
f2 = "/data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shCont/Hela_m6A-seq_shCont_input.sorted.bam"
f3 = "/data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shWTAP/Hela_m6A-seq_shWTAP_IP.sorted.bam"
f4 = "/data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shWTAP/Hela_m6A-seq_shWTAP_input.sorted.bam"

result = exomepeak(GENE_ANNO_GTF=gtf, IP_BAM=f1, INPUT_BAM=f2, TREATED_IP_BAM=f3, TREATED_INPUT_BAM=f4)

##rename and remove files
file.rename("./exomePeak_output/con_sig_diff_peak.bed", "./../Hela_shWTAP_diff_peak.bed")
file.rename("./exomePeak_output/con_sig_diff_peak.xls", "./../Hela_shWTAP_diff_peak.xls")

file.remove("./exomePeak_output/exomePeak.Rdata", "./exomePeak_output/diff_peak.bed", "./exomePeak_output/sig_diff_peak.bed",
	"./exomePeak_output/diff_peak.xls", "./exomePeak_output/sig_diff_peak.xls", "./exomePeak_output")
setwd("./../")
file.remove("./shWTAP")
