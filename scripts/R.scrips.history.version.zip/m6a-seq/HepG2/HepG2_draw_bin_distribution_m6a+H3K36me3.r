
library("ggplot2")
library("reshape2")
library("grid")

setwd("H:/lab_data/project/SETD2/report/2017.11.7/m6a-seq/HepG2/m6a-H3K36me3")

utr5Text = textGrob(paste("5' UTR", sep = " "))
cdsText = textGrob(paste("CDS", sep = " "))
utr3Text = textGrob(paste("3' UTR", sep = " "))

myData <- read.table("HepG2_m6a_H3K36me3.bed6bin",sep="\t",header = TRUE)
dataWithH3K36me3 <- myData[1:4]
reshapeData <- melt(dataWithH3K36me3,id=c("region", "bin"))

levels(reshapeData$variable)[levels(reshapeData$variable)=="shCont.H3K36me3.."] <- "HepG2 shNS"
levels(reshapeData$variable)[levels(reshapeData$variable)=="shSetD2.H3K36me3.."] <- "HepG2 shSETD2"

annotation_position = -11
HepG2_m6a_with_H3K36me3_bed6_bin <- ggplot(data=reshapeData, aes(x=bin, y=value)) +
  geom_line(aes(colour=variable), size=1.5) +
  scale_color_manual(values=c("#1b6ab1", "#ca5713")) + theme_bw() +
  geom_vline(aes(xintercept=100), colour="#BB0000", linetype="dashed") +
  geom_vline(aes(xintercept=200), colour="#BB0000", linetype="dashed") + labs(y = "m6A peaks in H3K36me3+ sites") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))+
  theme(axis.title = element_text(size = 13, face = "bold"), axis.title.x=element_blank(),axis.text.x=element_blank())+
  theme(axis.text = element_text(size = 11, face = "bold"), legend.text = element_text(size = 9, face = "bold"), legend.title=element_blank(),)+
  theme(legend.key.width=unit(1.5,"line"),legend.key.height=unit(1.5,"line"), legend.justification=c(1,0), legend.position=c(0.3,0.7))+
  theme(plot.margin = unit(c(1,1,3,1), "cm"))+
  scale_y_continuous(limits=c(0,160)) +
  annotation_custom(grob = utr5Text, xmin = 50, xmax = 50, ymin = annotation_position, ymax = annotation_position)+
  annotation_custom(grob = cdsText, xmin = 150, xmax = 150, ymin = annotation_position, ymax = annotation_position)+
  annotation_custom(grob = utr3Text, xmin = 250, xmax = 250, ymin = annotation_position, ymax = annotation_position)

HepG2_m6a_with_H3K36me3_bed6_bin <- ggplotGrob(HepG2_m6a_with_H3K36me3_bed6_bin)
HepG2_m6a_with_H3K36me3_bed6_bin$layout$clip[HepG2_m6a_with_H3K36me3_bed6_bin$layout$name=="panel"] <- "off"
grid.draw(HepG2_m6a_with_H3K36me3_bed6_bin)

pdf("HepG2_m6a_with_H3K36me3_bed6_bin.pdf")
plot(HepG2_m6a_with_H3K36me3_bed6_bin)
dev.off()

dataWithoutH3K36me3 <- myData[c(1,2,5,6)]
reshapeData <- melt(dataWithoutH3K36me3,id=c("region", "bin"))

levels(reshapeData$variable)[levels(reshapeData$variable)=="shCont.H3K36me3...1"] <- "HepG2 shNS"
levels(reshapeData$variable)[levels(reshapeData$variable)=="shSetD2.H3K36me3...1"] <- "HepG2 shSETD2"

HepG2_m6a_without_H3K36me3_bed6_bin <- ggplot(data=reshapeData, aes(x=bin, y=value)) +
  geom_line(aes(colour=variable), size=1.5) +
  scale_color_manual(values=c("#1b6ab1", "#ca5713")) + theme_bw() +
  geom_vline(aes(xintercept=100), colour="#BB0000", linetype="dashed") +
  geom_vline(aes(xintercept=200), colour="#BB0000", linetype="dashed") + labs(y = "m6A peaks in H3K36me3- sites") +
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))+
  theme(axis.title = element_text(size = 13, face = "bold"), axis.title.x=element_blank(),axis.text.x=element_blank())+
  theme(axis.text = element_text(size = 11, face = "bold"), legend.text = element_text(size = 9, face = "bold"), legend.title=element_blank(),)+
  theme(legend.key.width=unit(1.5,"line"),legend.key.height=unit(1.5,"line"), legend.justification=c(1,0), legend.position=c(0.3,0.7))+
  theme(plot.margin = unit(c(1,1,3,1), "cm"))+
  scale_y_continuous(limits=c(0,160)) +
  annotation_custom(grob = utr5Text, xmin = 50, xmax = 50, ymin = annotation_position, ymax = annotation_position)+
  annotation_custom(grob = cdsText, xmin = 150, xmax = 150, ymin = annotation_position, ymax = annotation_position)+
  annotation_custom(grob = utr3Text, xmin = 250, xmax = 250, ymin = annotation_position, ymax = annotation_position)

HepG2_m6a_without_H3K36me3_bed6_bin <- ggplotGrob(HepG2_m6a_without_H3K36me3_bed6_bin)
HepG2_m6a_without_H3K36me3_bed6_bin$layout$clip[HepG2_m6a_without_H3K36me3_bed6_bin$layout$name=="panel"] <- "off"
grid.draw(HepG2_m6a_without_H3K36me3_bed6_bin)

pdf("HepG2_m6a_without_H3K36me3_bed6_bin.pdf")
plot(HepG2_m6a_without_H3K36me3_bed6_bin)
dev.off()

myData <- read.table("HepG2_m6a_H3K36me3_peakNum.txt",sep="\t",header = TRUE)
reshapeData <- melt(myData,id=c("type"))
levels(reshapeData$variable)[levels(reshapeData$variable)=="H3K36me3."] <- "H3K36me3+"
levels(reshapeData$variable)[levels(reshapeData$variable)=="H3K36me3..1"] <- "H3K36me3-"
HepG2_m6a_H3K36me3_bed6_barplot <- ggplot(data=reshapeData, aes(x=variable, y=value, fill=type)) + geom_bar(stat="identity", position=position_dodge()) +
  labs(y = "m6A peak number") +
  theme(axis.title = element_text(size = 12, face = "bold"), axis.title.x=element_blank())+
  theme(panel.grid.major = element_blank(), panel.grid.minor = element_blank(), panel.background = element_blank(), axis.line = element_line(colour = "black"))+
  theme(axis.text = element_text(size = 10), legend.text = element_text(size = 9), legend.title=element_blank(),)+
  theme(legend.key.width=unit(1,"line"),legend.key.height=unit(1,"line"), legend.justification=c(1,0), legend.position=c(0.18,0.8))

pdf("HepG2_m6a_H3K36me3_bed6_barplot.pdf", width=6)
plot(HepG2_m6a_H3K36me3_bed6_barplot)
dev.off()

