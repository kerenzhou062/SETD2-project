#!/bin/sh
cd /data/zhoukr/hhl_setd2_m6a/analysis/RNA-seq/
find . -type d | sort | grep "Hela/IP/transcript" | xargs -I {} rm -rf {}
mkdir -p Hela/IP/transcript
cd Hela/IP/transcript
echo "Hela RNA-seq:"
echo -e "\nshCont-rep1\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shCont/Hela_m6A-seq_shCont_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shCont_htseq-count_rep1.txt

echo -e "\nshCont-rep2\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shCont/Hela_m6A-seq_shCont_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shCont_htseq-count_rep2.txt

echo -e "\nshCont-rep3\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shCont/Hela_m6A-seq_shCont_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shCont_htseq-count_rep3.txt
echo -e "\nshM14-rep1\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shM14/Hela_m6A-seq_shM14_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shM14_htseq-count_rep1.txt

echo -e "\nshM14-rep2\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shM14/Hela_m6A-seq_shM14_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shM14_htseq-count_rep2.txt

echo -e "\nshM14-rep3\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shM14/Hela_m6A-seq_shM14_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shM14_htseq-count_rep3.txt

echo -e "\nshM3-rep1\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shM3/Hela_m6A-seq_shM3_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shM3_htseq-count_rep1.txt

echo -e "\nshM3-rep2\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shM3/Hela_m6A-seq_shM3_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shM3_htseq-count_rep2.txt

echo -e "\nshM3-rep3\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shM3/Hela_m6A-seq_shM3_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shM3_htseq-count_rep3.txt
echo -e "\nshWTAP-rep1\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shWTAP/Hela_m6A-seq_shWTAP_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shWTAP_htseq-count_rep1.txt

echo -e "\nshWTAP-rep2\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shWTAP/Hela_m6A-seq_shWTAP_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shWTAP_htseq-count_rep2.txt

echo -e "\nshWTAP-rep3\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shWTAP/Hela_m6A-seq_shWTAP_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shWTAP_htseq-count_rep3.txt
echo -e "\nshSetD2-rep1\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shSetD2/Hela_m6A-seq_shSetD2_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shSetD2_htseq-count_rep1.txt

echo -e "\nshSetD2-rep2\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shSetD2/Hela_m6A-seq_shSetD2_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shSetD2_htseq-count_rep2.txt

echo -e "\nshSetD2-rep3\n"
htseq-count -s reverse -i transcript_id -f bam /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq/shSetD2/Hela_m6A-seq_shSetD2_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > Hela_shSetD2_htseq-count_rep3.txt


echo -e "\nshCont-shSetD2-group\n"
htseqCountGroup.pl -f Hela_shCont_htseq-count_rep1.txt Hela_shCont_htseq-count_rep2.txt Hela_shCont_htseq-count_rep3.txt \
  Hela_shSetD2_htseq-count_rep1.txt Hela_shSetD2_htseq-count_rep2.txt Hela_shSetD2_htseq-count_rep3.txt \
  -o ./Hela_RNA-seq_shCont-shSetD2_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshSetD2-1\tshSetD2-2\tshSetD2-3' ./Hela_RNA-seq_shCont-shSetD2_htseq-count.txt

echo -e "\nshCont-shM14-group\n"
htseqCountGroup.pl -f Hela_shCont_htseq-count_rep1.txt Hela_shCont_htseq-count_rep2.txt Hela_shCont_htseq-count_rep3.txt \
  Hela_shM14_htseq-count_rep1.txt Hela_shM14_htseq-count_rep2.txt Hela_shM14_htseq-count_rep3.txt \
  -o ./Hela_RNA-seq_shCont-shM14_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshM14-1\tshM14-2\tshM14-3' ./Hela_RNA-seq_shCont-shM14_htseq-count.txt

echo -e "\nshCont-shM3-group\n"
htseqCountGroup.pl -f Hela_shCont_htseq-count_rep1.txt Hela_shCont_htseq-count_rep2.txt Hela_shCont_htseq-count_rep3.txt \
  Hela_shM3_htseq-count_rep1.txt Hela_shM3_htseq-count_rep2.txt Hela_shM3_htseq-count_rep3.txt \
  -o ./Hela_RNA-seq_shCont-shM3_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshM3-1\tshM3-2\tshM3-3' ./Hela_RNA-seq_shCont-shM3_htseq-count.txt

echo -e "\nshCont-shWTAP-group\n"
htseqCountGroup.pl -f Hela_shCont_htseq-count_rep1.txt Hela_shCont_htseq-count_rep2.txt Hela_shCont_htseq-count_rep3.txt \
  Hela_shWTAP_htseq-count_rep1.txt Hela_shWTAP_htseq-count_rep2.txt Hela_shWTAP_htseq-count_rep3.txt \
  -o ./Hela_RNA-seq_shCont-shWTAP_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshWTAP-1\tshWTAP-2\tshWTAP-3' ./Hela_RNA-seq_shCont-shWTAP_htseq-count.txt

