#!/bin/sh

### Hela, ChIP-seq
cd /data/zhoukr/hhl_setd2_m6a/analysis/RNA-seq/HepG2/IPvsInput
annotation=/data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.all.longest.exon.bed6
geneExpDir=/data/zhoukr/hhl_setd2_m6a/analysis/RNA-seq/HepG2/RSEM

echo -e "GeneID\tgeneName\tlogFC\tlogCPM\tMeanFPKM\tLR\tPValue\tFDR" > HepG2_RNA-seq_gene_m6A_level_shCont_stats.txt
awk 'BEGIN{OFS="\t";}
    ARGIND==1{
        split($4,geneIdI,":");
        geneIdi=geneIdI[1];
        geneNamei=geneIdI[2];
        hashGeneIdName[geneIdi]=geneNamei;
    }
    ARGIND==2{
        if(FNR>1){
            hashGeneExp[$1]=$6;
        }
    }
    ARGIND==3{
        if(FNR>1){
            if($3>=1 && $2 in hashGeneExp){
                print $2,hashGeneIdName[$2],$3,hashGeneExp[$2],$4,$5,$6,$7;
            }
        }
    }' $annotation $geneExpDir/HepG2_RNA-seq_RSEM_shCont_input.txt HepG2_m6A-seq_shCont_htseq-count_gene-edgeR.FC.txt >> HepG2_RNA-seq_gene_m6A_level_shCont_stats.txt


echo -e "GeneID\tgeneName\tm6ALevelLog2FC\tm6ALevelInshCont(log2)\tpVal_shCont\tpVal_shSetD2" > HepG2_RNA-seq_gene_m6A_level_FC_shSetD2vsshCont.txt
awk 'BEGIN{OFS="\t";}
    ARGIND==1{
        split($4,geneIdI,":");
        geneIdi=geneIdI[1];
        geneNamei=geneIdI[2];
        hashGeneIdName[geneIdi]=geneNamei;
    }
    ARGIND==2{
        if(FNR>1){
            hashGeneExp[$1]=$6;
        }
    }
    ARGIND==3{
        if(FNR>1){
            hashFC[$2]= $3;
            hashPval[$2]= $6;
        }
    }
    ARGIND==4{
        if(FNR>1){
            if(hashFC[$2]>=1 && $2 in hashGeneExp){
                FC=$3-hashFC[$2];
                print $2,hashGeneIdName[$2],FC,hashFC[$2],hashPval[$2],$6;
            }
        }
    }' $annotation $geneExpDir/HepG2_RNA-seq_RSEM_shSetD2_input.txt HepG2_m6A-seq_shCont_htseq-count_gene-edgeR.FC.txt HepG2_m6A-seq_shSetD2_htseq-count_gene-edgeR.FC.txt >> HepG2_RNA-seq_gene_m6A_level_FC_shSetD2vsshCont.txt

echo -e "GeneID\tgeneName\tm6ALevelLog2FC\tm6ALevelInshCont(log2)\tpVal_shCont\tpVal_shM14" > HepG2_RNA-seq_gene_m6A_level_FC_shM14vsshCont.txt
awk 'BEGIN{OFS="\t";}
    ARGIND==1{
        split($4,geneIdI,":");
        geneIdi=geneIdI[1];
        geneNamei=geneIdI[2];
        hashGeneIdName[geneIdi]=geneNamei;
    }
    ARGIND==2{
        if(FNR>1){
            hashGeneExp[$1]=$6;
        }
    }
    ARGIND==3{
        if(FNR>1){
            hashFC[$2]= $3;
            hashPval[$2]= $6;
        }
    }
    ARGIND==4{
        if(FNR>1){
            if(hashFC[$2]>=1 && $2 in hashGeneExp){
                FC=$3-hashFC[$2];
                print $2,hashGeneIdName[$2],FC,hashFC[$2],hashPval[$2],$6;
            }
        }
    }' $annotation $geneExpDir/HepG2_RNA-seq_RSEM_shM14_input.txt HepG2_m6A-seq_shCont_htseq-count_gene-edgeR.FC.txt HepG2_m6A-seq_shM14_htseq-count_gene-edgeR.FC.txt >> HepG2_RNA-seq_gene_m6A_level_FC_shM14vsshCont.txt

echo -e "GeneID\tgeneName\tm6ALevelLog2FC\tm6ALevelInshCont(log2)\tpVal_shCont\tpVal_shM3" > HepG2_RNA-seq_gene_m6A_level_FC_shM3vsshCont.txt
awk 'BEGIN{OFS="\t";}
    ARGIND==1{
        split($4,geneIdI,":");
        geneIdi=geneIdI[1];
        geneNamei=geneIdI[2];
        hashGeneIdName[geneIdi]=geneNamei;
    }
    ARGIND==2{
        if(FNR>1){
            hashGeneExp[$1]=$6;
        }
    }
    ARGIND==3{
        if(FNR>1){
            hashFC[$2]= $3;
            hashPval[$2]= $6;
        }
    }
    ARGIND==4{
        if(FNR>1){
            if(hashFC[$2]>=1 && $2 in hashGeneExp){
                FC=$3-hashFC[$2];
                print $2,hashGeneIdName[$2],FC,hashFC[$2],hashPval[$2],$6;
            }
        }
    }' $annotation $geneExpDir/HepG2_RNA-seq_RSEM_shM3_input.txt HepG2_m6A-seq_shCont_htseq-count_gene-edgeR.FC.txt HepG2_m6A-seq_shM3_htseq-count_gene-edgeR.FC.txt >> HepG2_RNA-seq_gene_m6A_level_FC_shM3vsshCont.txt

echo -e "GeneID\tgeneName\tm6ALevelLog2FC\tm6ALevelInshCont(log2)\tpVal_shCont\tpVal_shWTAP" > HepG2_RNA-seq_gene_m6A_level_FC_shWTAPvsshCont.txt
awk 'BEGIN{OFS="\t";}
    ARGIND==1{
        split($4,geneIdI,":");
        geneIdi=geneIdI[1];
        geneNamei=geneIdI[2];
        hashGeneIdName[geneIdi]=geneNamei;
    }
    ARGIND==2{
        if(FNR>1){
            hashGeneExp[$1]=$6;
        }
    }
    ARGIND==3{
        if(FNR>1){
            hashFC[$2]= $3;
            hashPval[$2]= $6;
        }
    }
    ARGIND==4{
        if(FNR>1){
            if(hashFC[$2]>=1 && $2 in hashGeneExp){
                FC=$3-hashFC[$2];
                print $2,hashGeneIdName[$2],FC,hashFC[$2],hashPval[$2],$6;
            }
        }
    }' $annotation $geneExpDir/HepG2_RNA-seq_RSEM_shWTAP_input.txt HepG2_m6A-seq_shCont_htseq-count_gene-edgeR.FC.txt HepG2_m6A-seq_shWTAP_htseq-count_gene-edgeR.FC.txt >> HepG2_RNA-seq_gene_m6A_level_FC_shWTAPvsshCont.txt
