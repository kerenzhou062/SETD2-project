#!/bin/sh
cd /data/zhoukr/hhl_setd2_m6a/analysis/RNA-seq/HepG2
htseqCountGroup.pl -f input/gene/HepG2_shCont_htseq-count_rep1.txt input/gene/HepG2_shCont_htseq-count_rep2.txt input/gene/HepG2_shCont_htseq-count_rep3.txt \
  IP/gene/HepG2_shCont_htseq-count_rep1.txt IP/gene/HepG2_shCont_htseq-count_rep2.txt IP/gene/HepG2_shCont_htseq-count_rep3.txt \
  -o IPvsInput/HepG2_RNA-seq_shCont_htseq-count_gene.txt
sed -i '1i geneID\tshContInput-1\tshContInput-2\tshContInput-3\tshContIP-1\tshContIP-2\tshContIP-3' IPvsInput/HepG2_RNA-seq_shCont_htseq-count_gene.txt

htseqCountGroup.pl -f input/gene/HepG2_shSetD2_htseq-count_rep1.txt input/gene/HepG2_shSetD2_htseq-count_rep2.txt input/gene/HepG2_shSetD2_htseq-count_rep3.txt \
  IP/gene/HepG2_shSetD2_htseq-count_rep1.txt IP/gene/HepG2_shSetD2_htseq-count_rep2.txt IP/gene/HepG2_shSetD2_htseq-count_rep3.txt \
  -o IPvsInput/HepG2_RNA-seq_shSetD2_htseq-count_gene.txt
sed -i '1i geneID\tshSetD2Input-1\tshSetD2Input-2\tshSetD2Input-3\tshSetD2IP-1\tshSetD2IP-2\tshSetD2IP-3' IPvsInput/HepG2_RNA-seq_shSetD2_htseq-count_gene.txt

htseqCountGroup.pl -f input/gene/HepG2_shM14_htseq-count_rep1.txt input/gene/HepG2_shM14_htseq-count_rep2.txt input/gene/HepG2_shM14_htseq-count_rep3.txt \
  IP/gene/HepG2_shM14_htseq-count_rep1.txt IP/gene/HepG2_shM14_htseq-count_rep2.txt IP/gene/HepG2_shM14_htseq-count_rep3.txt \
  -o IPvsInput/HepG2_RNA-seq_shM14_htseq-count_gene.txt
sed -i '1i geneID\tshM14Input-1\tshM14Input-2\tshM14Input-3\tshM14IP-1\tshM14IP-2\tshM14IP-3' IPvsInput/HepG2_RNA-seq_shM14_htseq-count_gene.txt

htseqCountGroup.pl -f input/gene/HepG2_shM3_htseq-count_rep1.txt input/gene/HepG2_shM3_htseq-count_rep2.txt input/gene/HepG2_shM3_htseq-count_rep3.txt \
  IP/gene/HepG2_shM3_htseq-count_rep1.txt IP/gene/HepG2_shM3_htseq-count_rep2.txt IP/gene/HepG2_shM3_htseq-count_rep3.txt \
  -o IPvsInput/HepG2_RNA-seq_shM3_htseq-count_gene.txt
sed -i '1i geneID\tshM3Input-1\tshM3Input-2\tshM3Input-3\tshM3IP-1\tshM3IP-2\tshM3IP-3' IPvsInput/HepG2_RNA-seq_shM3_htseq-count_gene.txt

htseqCountGroup.pl -f input/gene/HepG2_shWTAP_htseq-count_rep1.txt input/gene/HepG2_shWTAP_htseq-count_rep2.txt input/gene/HepG2_shWTAP_htseq-count_rep3.txt \
  IP/gene/HepG2_shWTAP_htseq-count_rep1.txt IP/gene/HepG2_shWTAP_htseq-count_rep2.txt IP/gene/HepG2_shWTAP_htseq-count_rep3.txt \
  -o IPvsInput/HepG2_RNA-seq_shWTAP_htseq-count_gene.txt
sed -i '1i geneID\tshWTAPInput-1\tshWTAPInput-2\tshWTAPInput-3\tshWTAPIP-1\tshWTAPIP-2\tshWTAPIP-3' IPvsInput/HepG2_RNA-seq_shWTAP_htseq-count_gene.txt

