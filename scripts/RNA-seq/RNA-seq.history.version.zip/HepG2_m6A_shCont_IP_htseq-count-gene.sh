#!/bin/sh
cd /data/zhoukr/hhl_setd2_m6a/analysis/RNA-seq/
find . -type d | sort | grep "HepG2/IP/gene" | awk '{if(FNR>1)print}' | xargs -I {} rm -rf {}
mkdir -p HepG2/IP/gene
cd HepG2/IP/gene
echo "HepG2 RNA-seq:"
echo -e "\nshCont-rep1\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shCont/HepG2_m6A-seq_shCont_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shCont_htseq-count_rep1.txt

echo -e "\nshCont-rep2\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shCont/HepG2_m6A-seq_shCont_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shCont_htseq-count_rep2.txt

echo -e "\nshCont-rep3\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shCont/HepG2_m6A-seq_shCont_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shCont_htseq-count_rep3.txt
echo -e "\nshM14-rep1\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM14/HepG2_m6A-seq_shM14_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shM14_htseq-count_rep1.txt

echo -e "\nshM14-rep2\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM14/HepG2_m6A-seq_shM14_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shM14_htseq-count_rep2.txt

echo -e "\nshM14-rep3\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM14/HepG2_m6A-seq_shM14_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shM14_htseq-count_rep3.txt

echo -e "\nshM3-rep1\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM3/HepG2_m6A-seq_shM3_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shM3_htseq-count_rep1.txt

echo -e "\nshM3-rep2\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM3/HepG2_m6A-seq_shM3_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shM3_htseq-count_rep2.txt

echo -e "\nshM3-rep3\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM3/HepG2_m6A-seq_shM3_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shM3_htseq-count_rep3.txt
echo -e "\nshWTAP-rep1\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shWTAP/HepG2_m6A-seq_shWTAP_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shWTAP_htseq-count_rep1.txt

echo -e "\nshWTAP-rep2\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shWTAP/HepG2_m6A-seq_shWTAP_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shWTAP_htseq-count_rep2.txt

echo -e "\nshWTAP-rep3\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shWTAP/HepG2_m6A-seq_shWTAP_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shWTAP_htseq-count_rep3.txt
echo -e "\nshSetD2-rep1\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shSetD2/HepG2_m6A-seq_shSetD2_IP_rep1.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shSetD2_htseq-count_rep1.txt

echo -e "\nshSetD2-rep2\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shSetD2/HepG2_m6A-seq_shSetD2_IP_rep2.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shSetD2_htseq-count_rep2.txt

echo -e "\nshSetD2-rep3\n"
htseq-count -s reverse -i gene_id -f bam /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shSetD2/HepG2_m6A-seq_shSetD2_IP_rep3.fastq.sorted.bam \
  /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.gtf > HepG2_shSetD2_htseq-count_rep3.txt


echo -e "\nshCont-shSetD2-group\n"
htseqCountGroup.pl -f HepG2_shCont_htseq-count_rep1.txt HepG2_shCont_htseq-count_rep2.txt HepG2_shCont_htseq-count_rep3.txt \
  HepG2_shSetD2_htseq-count_rep1.txt HepG2_shSetD2_htseq-count_rep2.txt HepG2_shSetD2_htseq-count_rep3.txt \
  -o ./HepG2_RNA-seq_shCont-shSetD2_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshSetD2-1\tshSetD2-2\tshSetD2-3' ./HepG2_RNA-seq_shCont-shSetD2_htseq-count.txt

echo -e "\nshCont-shM14-group\n"
htseqCountGroup.pl -f HepG2_shCont_htseq-count_rep1.txt HepG2_shCont_htseq-count_rep2.txt HepG2_shCont_htseq-count_rep3.txt \
  HepG2_shM14_htseq-count_rep1.txt HepG2_shM14_htseq-count_rep2.txt HepG2_shM14_htseq-count_rep3.txt \
  -o ./HepG2_RNA-seq_shCont-shM14_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshM14-1\tshM14-2\tshM14-3' ./HepG2_RNA-seq_shCont-shM14_htseq-count.txt

echo -e "\nshCont-shM3-group\n"
htseqCountGroup.pl -f HepG2_shCont_htseq-count_rep1.txt HepG2_shCont_htseq-count_rep2.txt HepG2_shCont_htseq-count_rep3.txt \
  HepG2_shM3_htseq-count_rep1.txt HepG2_shM3_htseq-count_rep2.txt HepG2_shM3_htseq-count_rep3.txt \
  -o ./HepG2_RNA-seq_shCont-shM3_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshM3-1\tshM3-2\tshM3-3' ./HepG2_RNA-seq_shCont-shM3_htseq-count.txt

echo -e "\nshCont-shWTAP-group\n"
htseqCountGroup.pl -f HepG2_shCont_htseq-count_rep1.txt HepG2_shCont_htseq-count_rep2.txt HepG2_shCont_htseq-count_rep3.txt \
  HepG2_shWTAP_htseq-count_rep1.txt HepG2_shWTAP_htseq-count_rep2.txt HepG2_shWTAP_htseq-count_rep3.txt \
  -o ./HepG2_RNA-seq_shCont-shWTAP_htseq-count.txt
sed -i '1i geneID\tshCont-1\tshCont-2\tshCont-3\tshWTAP-1\tshWTAP-2\tshWTAP-3' ./HepG2_RNA-seq_shCont-shWTAP_htseq-count.txt

