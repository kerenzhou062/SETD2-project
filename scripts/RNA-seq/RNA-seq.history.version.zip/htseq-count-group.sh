#!/bin/sh
## Hela
htseqCountGroup.pl -f Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shSetD2_htseq-count.txt Hela_RNA-seq_shSetD2_htseq-count.txt -o ./Hela_RNA-seq_shCont-shSetD2_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshSetD2-1\tshSetD2-2' ./Hela_RNA-seq_shCont-shSetD2_htseq-count.txt

htseqCountGroup.pl -f Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shM14_htseq-count.txt Hela_RNA-seq_shM14_htseq-count.txt -o ./Hela_RNA-seq_shCont-shM14_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshM14-1\tshM14-2' ./Hela_RNA-seq_shCont-shM14_htseq-count.txt

htseqCountGroup.pl -f Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shM3_htseq-count.txt Hela_RNA-seq_shM3_htseq-count.txt -o ./Hela_RNA-seq_shCont-shM3_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshM3-1\tshM3-2' ./Hela_RNA-seq_shCont-shM3_htseq-count.txt

htseqCountGroup.pl -f Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shCont_htseq-count.txt Hela_RNA-seq_shWTAP_htseq-count.txt Hela_RNA-seq_shWTAP_htseq-count.txt -o ./Hela_RNA-seq_shCont-shWTAP_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshWTAP-1\tshWTAP-2' ./Hela_RNA-seq_shCont-shWTAP_htseq-count.txt

## HepG2

htseqCountGroup.pl -f HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shSetD2_htseq-count.txt HepG2_RNA-seq_shSetD2_htseq-count.txt -o ./HepG2_RNA-seq_shCont-shSetD2_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshSetD2-1\tshSetD2-2' ./HepG2_RNA-seq_shCont-shSetD2_htseq-count.txt

htseqCountGroup.pl -f HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shM14_htseq-count.txt HepG2_RNA-seq_shM14_htseq-count.txt -o ./HepG2_RNA-seq_shCont-shM14_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshM14-1\tshM14-2' ./HepG2_RNA-seq_shCont-shM14_htseq-count.txt

htseqCountGroup.pl -f HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shM3_htseq-count.txt HepG2_RNA-seq_shM3_htseq-count.txt -o ./HepG2_RNA-seq_shCont-shM3_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshM3-1\tshM3-2' ./HepG2_RNA-seq_shCont-shM3_htseq-count.txt

htseqCountGroup.pl -f HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shCont_htseq-count.txt HepG2_RNA-seq_shWTAP_htseq-count.txt HepG2_RNA-seq_shWTAP_htseq-count.txt -o ./HepG2_RNA-seq_shCont-shWTAP_htseq-count.txt
sed  -i '1i geneID\tshCont-1\tshCont-2\tshWTAP-1\tshWTAP-2' ./HepG2_RNA-seq_shCont-shWTAP_htseq-count.txt