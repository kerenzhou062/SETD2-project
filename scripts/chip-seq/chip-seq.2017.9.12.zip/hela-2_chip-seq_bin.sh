#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/Hela_ChIP-seq2/
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela-2/bed6
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela-2/bed6

macsXlsPeakFilter.pl -x shCont/Hela_shCont_peaks.xls -name shCont_macs -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela-2/bed6/Hela_macs_shCont_peaks.bed
macsXlsPeakFilter.pl -x shSetD2/Hela_shSetD2_peaks.xls -name shSetD2_macs -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela-2/bed6/Hela_macs_shSetD2_peaks.bed

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela-2/bed6

bed2exclude.pl -a Hela_macs_shCont_peaks.bed -b Hela_macs_shSetD2_peaks.bed -o ./Hela_shCont_SetD2_dependent.bed

#####

bedBinDistribution.pl -span 10 -smooth move -t count --input Hela_macs_shCont_peaks.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./Hela_chip_shCont.bin
bedBinDistribution.pl -span 10 -smooth move -t count --input Hela_macs_shSetD2_peaks.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./Hela_chip_shSetD2.bin
paste Hela_chip_shCont.bin Hela_chip_shSetD2.bin | cut -f 1,2,3,6 > Hela_chip_all.bin
sed  -i '1i region\tbin\tshCont\tshSetD2' Hela_chip_all.bin
rm -f Hela_chip_shCont.bin Hela_chip_shSetD2.bin

