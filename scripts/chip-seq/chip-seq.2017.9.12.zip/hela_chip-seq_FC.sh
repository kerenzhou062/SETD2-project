#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/Hela_ChIP-seq

## xls
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls
macsXlsPeakFilter.pl -pval 0.05 -original -x shCont/shCont_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls/Hela_shCont_chip.xls
macsXlsPeakFilter.pl -pval 0.05 -original -x shSetD2/shSetD2_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls/Hela_shSetD2_chip.xls
macsXlsPeakFilter.pl -pval 0.05 -original -x shM14/shM14_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls/Hela_shM14_chip.xls
macsXlsPeakFilter.pl -pval 0.05 -original -x shM3/shM3_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls/Hela_shM3_chip.xls
macsXlsPeakFilter.pl -pval 0.05 -original -x shWTAP/shWTAP_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls/Hela_shWTAP_chip.xls

### peak fold_enrichment
cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/xls
mkdir allPeak
mkdir overlappedPeak
# all peak
macsPeakFC.pl -FE -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_FoldEnrichment.txt
macsPeakFC.pl -FE -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_-F0.5_FoldEnrichment.txt
macsPeakFC.pl -FE -log 2 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_FoldEnrichment_log2.txt
macsPeakFC.pl -FE -log 2 -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_-F0.5_FoldEnrichment_log2.txt
macsPeakFC.pl -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_FC.txt
macsPeakFC.pl -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_-F0.5_FC.txt
macsPeakFC.pl -log 2 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_FC_log2.txt
macsPeakFC.pl -log 2 -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./allPeak/Hela_chip_peak_-F0.5_FC_log2.txt

# overlapped peak
macsPeakFC.pl -overlap 0 1 1 1 1 -FE -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_FoldEnrichment.txt
macsPeakFC.pl -overlap 0 1 1 1 1 -FE -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_-F0.5_FoldEnrichment.txt
macsPeakFC.pl -overlap 0 1 1 1 1 -FE -log 2 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_FoldEnrichment_log2.txt
macsPeakFC.pl -overlap 0 1 1 1 1 -FE -log 2 -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_-F0.5_FoldEnrichment_log2.txt
macsPeakFC.pl -overlap 0 1 1 1 1 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_FC.txt
macsPeakFC.pl -overlap 0 1 1 1 1 -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_-F0.5_FC.txt
macsPeakFC.pl -overlap 0 1 1 1 1 -log 2 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_FC_log2.txt
macsPeakFC.pl -overlap 0 1 1 1 1 -log 2 -F 0.5 -x Hela_shCont_chip.xls Hela_shSetD2_chip.xls Hela_shM14_chip.xls Hela_shM3_chip.xls Hela_shWTAP_chip.xls -o ./overlappedPeak/Hela_chip_peak_-F0.5_FC_log2.txt
