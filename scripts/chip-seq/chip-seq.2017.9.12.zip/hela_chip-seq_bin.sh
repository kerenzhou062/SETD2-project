#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/Hela_ChIP-seq/
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6

macsXlsPeakFilter.pl -x shCont/shCont_macs_peaks.xls -name shCont_macs -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6/Hela_macs_shCont_peaks.bed
macsXlsPeakFilter.pl -x shSetD2/shSetD2_macs_peaks.xls -name shSetD2_macs -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6/Hela_macs_shSetD2_peaks.bed
macsXlsPeakFilter.pl -x shM14/shM14_macs_peaks.xls -name shM14_macs -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6/Hela_macs_shM14_peaks.bed
macsXlsPeakFilter.pl -x shM3/shM3_macs_peaks.xls -name shM3_macs -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6/Hela_macs_shM3_peaks.bed
macsXlsPeakFilter.pl -x shWTAP/shWTAP_macs_peaks.xls -name shWTAP_macs -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6/Hela_macs_shWTAP_peaks.bed

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/Hela/bed6

bed2exclude.pl -a Hela_macs_shCont_peaks.bed -b Hela_macs_shSetD2_peaks.bed -o ./Hela_shCont_SetD2_dependent.bed

bed2exclude.pl -a Hela_macs_shCont_peaks.bed -b Hela_macs_shM14_peaks.bed -o ./Hela_shCont_M14_dependent.bed
bed2overlap.pl -aOver -a Hela_macs_shSetD2_peaks.bed -b Hela_shCont_M14_dependent.bed -o ./Hela_shSetD2_M14_dependent.bed

bed2exclude.pl -a Hela_macs_shCont_peaks.bed -b Hela_macs_shM3_peaks.bed -o ./Hela_shCont_M3_dependent.bed
bed2overlap.pl -aOver -a Hela_macs_shSetD2_peaks.bed -b Hela_shCont_M3_dependent.bed -o ./Hela_shSetD2_M3_dependent.bed

bed2exclude.pl -a Hela_macs_shCont_peaks.bed -b Hela_macs_shWTAP_peaks.bed -o ./Hela_shCont_WTAP_dependent.bed
bed2overlap.pl -aOver -a Hela_macs_shSetD2_peaks.bed -b Hela_shCont_WTAP_dependent.bed -o ./Hela_shSetD2_WTAP_dependent.bed

#####
cat Hela_shCont_M14_dependent.bed Hela_shCont_M3_dependent.bed Hela_shCont_WTAP_dependent.bed | sort -t $'\t' -k1,1V -k2,2n | uniq > Hela_shCont_allWriter_targets.bed
bed2exclude.pl -a Hela_macs_shCont_peaks.bed -b Hela_shCont_allWriter_targets.bed -o ./Hela_chip_shCont_nonWriter_dependent.bed
bed2overlap.pl -aOver -a Hela_macs_shSetD2_peaks.bed -b Hela_chip_shCont_nonWriter_dependent.bed -o ./Hela_chip_shSetD2_nonWriter_dependent.bed

###draw bin distribution based on count and bed12 for writer targets

bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_shCont_M14_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_shCont_M14_dependent.bin
bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_shSetD2_M14_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_shSetD2_M14_dependent.bin
paste Hela_shCont_M14_dependent.bin Hela_shSetD2_M14_dependent.bin | cut -f 1,2,3,6 > Hela_chip_M14_dependent.bin
sed  -i '1i region\tbin\tshCont\tshSetD2' Hela_chip_M14_dependent.bin
rm -f Hela_shCont_M14_dependent.bin Hela_shSetD2_M14_dependent.bin

bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_shCont_M3_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_shCont_M3_dependent.bin
bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_shSetD2_M3_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_shSetD2_M3_dependent.bin
paste Hela_shCont_M3_dependent.bin Hela_shSetD2_M3_dependent.bin | cut -f 1,2,3,6 > Hela_chip_M3_dependent.bin
sed  -i '1i region\tbin\tshCont\tshSetD2' Hela_chip_M3_dependent.bin
rm -f Hela_shCont_M3_dependent.bin Hela_shSetD2_M3_dependent.bin

bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_shCont_WTAP_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_shCont_WTAP_dependent.bin
bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_shSetD2_WTAP_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_shSetD2_WTAP_dependent.bin
paste Hela_shCont_WTAP_dependent.bin Hela_shSetD2_WTAP_dependent.bin | cut -f 1,2,3,6 > Hela_chip_WTAP_dependent.bin
sed  -i '1i region\tbin\tshCont\tshSetD2' Hela_chip_WTAP_dependent.bin
rm -f Hela_shCont_WTAP_dependent.bin Hela_shSetD2_WTAP_dependent.bin

bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_chip_shCont_nonWriter_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_chip_shCont_nonWriter_dependent.bin
bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_chip_shSetD2_nonWriter_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_chip_shSetD2_nonWriter_dependent.bin
paste Hela_chip_shCont_nonWriter_dependent.bin Hela_chip_shSetD2_nonWriter_dependent.bin | cut -f 1,2,3,6 > Hela_chip_nonWriter_dependent.bin
sed  -i '1i region\tbin\tshCont\tshSetD2' Hela_chip_nonWriter_dependent.bin
rm -f Hela_chip_shCont_nonWriter_dependent.bin Hela_chip_shSetD2_nonWriter_dependent.bin

bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_macs_shCont_peaks.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_chip_shCont.bin
bedBinDistribution.pl --feature promoter,5utr,cds,3utr -span 10 -smooth move -t count --input Hela_macs_shSetD2_peaks.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_chip_shSetD2.bin
paste Hela_chip_shCont.bin Hela_chip_shSetD2.bin | cut -f 1,2,3,6 > Hela_chip_all.bin
sed  -i '1i region\tbin\tshCont\tshSetD2' Hela_chip_all.bin
rm -f Hela_chip_shCont.bin Hela_chip_shSetD2.bin

#### gene type counts and region counts of SetD2 dependent H3K36me3 sites

regionDistribution.pl --feature promoter,5utr,cds,stopCodon,3utr --input Hela_shCont_SetD2_dependent.bed -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon+promoter.bed6 -o ./Hela_macs_shCont_SetD2_dependent.region
sed  -i '1i region\tpeakNumber\tenrichment' ./Hela_macs_shCont_SetD2_dependent.region
