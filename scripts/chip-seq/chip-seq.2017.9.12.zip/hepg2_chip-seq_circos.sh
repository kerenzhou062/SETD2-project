#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/HepG2_ChIP-seq/

macsXlsToCircos.pl -g human -x shCont/shCont_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shCont_circos.txt
macsXlsToCircos.pl -g human -x shSetD2/shSetD2_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shSetD2_circos.txt
macsXlsToCircos.pl -g human -x shM14/shM14_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shM14_circos.txt
macsXlsToCircos.pl -g human -x shM3/shM3_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shM3_circos.txt
macsXlsToCircos.pl -g human -x shWTAP/shWTAP_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shWTAP_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/

##scatter plot
cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/conf/scatter/original
circos -conf scatter.hs1.shCont_vs_shSetD2.conf > /dev/null 2>&1
circos -conf scatter.shCont_vs_shSetD2.conf > /dev/null 2>&1

cd /data/zhoukr/hhl_setd2_m6a/HepG2_ChIP-seq/

macsXlsToCircos.pl -g human -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x shCont/shCont_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shCont_circos.txt
macsXlsToCircos.pl -g human -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x shSetD2/shSetD2_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shSetD2_circos.txt
macsXlsToCircos.pl -g human -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x shM14/shM14_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shM14_circos.txt
macsXlsToCircos.pl -g human -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x shM3/shM3_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shM3_circos.txt
macsXlsToCircos.pl -g human -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x shWTAP/shWTAP_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/HepG2_macs_shWTAP_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/
paste HepG2_macs_shCont_circos.txt HepG2_macs_shSetD2_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > HepG2_macs_FC_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/conf/histogram/bin
circos -conf histogram.hs1.shCont_vs_shSetD2.conf > /dev/null 2>&1 &

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/conf/heatmap/bin
circos -conf heatmap.hs1.shCont_vs_all.conf > /dev/null 2>&1 &

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/HepG2/circos/conf/line/bin
circos -conf line.hs1.shCont_vs_shSetD2.conf > /dev/null 2>&1 &
