#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/mouse_ESCs_ChIP-seq/

macsXlsToCircos.pl -g mouse -x Ctrl_D0/Ctrl_D0_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/mESCs_macs_shCont_circos.txt
macsXlsToCircos.pl -g mouse -x SetD2-KD_D0/SetD2-KD_D0_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/mESCs_macs_shSetD2_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/

##scatter plot
cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/conf/scatter/original
circos -conf scatter.mm1.shCont_vs_shSetD2.conf > /dev/null 2>&1
circos -conf scatter.shCont_vs_shSetD2.conf > /dev/null 2>&1

cd /data/zhoukr/hhl_setd2_m6a/mouse_ESCs_ChIP-seq/

macsXlsToCircos.pl -g mouse -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x Ctrl_D0/Ctrl_D0_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/mESCs_macs_shCont_circos.txt
macsXlsToCircos.pl -g mouse -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x SetD2-KD_D0/SetD2-KD_D0_macs_peaks.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/mESCs_macs_shSetD2_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/
paste mESCs_macs_shCont_circos.txt mESCs_macs_shSetD2_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > mESCs_macs_FC_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/conf/histogram/bin
circos -conf histogram.mm1.shCont_vs_shSetD2.conf > /dev/null 2>&1 &

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/conf/heatmap/bin
circos -conf heatmap.mm1.shCont_vs_all.conf > /dev/null 2>&1 &

cd /data/zhoukr/hhl_setd2_m6a/analysis/chip-seq/mESCs/circos/conf/line/bin
circos -conf line.mm1.shCont_vs_shSetD2.conf > /dev/null 2>&1 &
