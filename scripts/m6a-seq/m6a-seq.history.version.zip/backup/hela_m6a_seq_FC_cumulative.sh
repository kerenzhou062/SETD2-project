#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls/allPeak
tatgetPath="./target"
if [ ! -d "$tatgetPath" ]
then
  mkdir "$tatgetPath"
fi

cd $tatgetPath

awk '{if(NR>1){cutoff=log(0.5)/log(2); if ($15 < cutoff) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shM14_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if ($16 < cutoff) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shM3_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if ($17 < cutoff) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shWTAP_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if (($15 < cutoff)&&($16 < cutoff)&&($17 < cutoff)) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shareTargets_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if (($15 >= cutoff)&&($16 >= cutoff)&&($17 >= cutoff)) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_nonTargets_FC_log2.txt

cumulativePlot.pl -header true -interval 0.01 --input Hela_-F0.5_shM14_FC_log2.txt Hela_-F0.5_shM3_FC_log2.txt Hela_-F0.5_shWTAP_FC_log2.txt Hela_-F0.5_shareTargets_FC_log2.txt Hela_-F0.5_nonTargets_FC_log2.txt -o ./../Hela_-F0.5_cumulativePlot.txt
sed -i '1i FC\tshM14\tshM3\tshWTAP\tshare\tnonTarget' ./../Hela_-F0.5_cumulativePlot.txt


cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls/overlappedPeak
if [ ! -d "$tatgetPath" ]
then
  mkdir "$tatgetPath"
fi

cd $tatgetPath

awk '{if(NR>1){cutoff=log(0.5)/log(2); if ($15 < cutoff) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shM14_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if ($16 < cutoff) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shM3_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if ($17 < cutoff) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shWTAP_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if (($15 < cutoff)&&($16 < cutoff)&&($17 < cutoff)) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_shareTargets_FC_log2.txt
awk '{if(NR>1){cutoff=log(0.5)/log(2); if (($15 >= cutoff)&&($16 >= cutoff)&&($17 >= cutoff)) {print $14;}}}' ./../Hela_m6a_peak_-F0.5_FC_log2.txt > Hela_-F0.5_nonTargets_FC_log2.txt

cumulativePlot.pl -header true -interval 0.01 --input Hela_-F0.5_shM14_FC_log2.txt Hela_-F0.5_shM3_FC_log2.txt Hela_-F0.5_shWTAP_FC_log2.txt Hela_-F0.5_shareTargets_FC_log2.txt Hela_-F0.5_nonTargets_FC_log2.txt -o ./../Hela_-F0.5_cumulativePlot.txt
sed -i '1i FC\tshM14\tshM3\tshWTAP\tshare\tnonTarget' ./../Hela_-F0.5_cumulativePlot.txt

