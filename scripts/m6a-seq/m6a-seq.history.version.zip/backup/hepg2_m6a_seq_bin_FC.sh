#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq

### bed12
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12
exomePeakToSummit.pl -p 0.05 -original -x shCont/shCont_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12/HepG2_shCont_m6a.bed12
exomePeakToSummit.pl -p 0.05 -original -x shSetD2/shSetD2_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12/HepG2_shSetD2_m6a.bed12
exomePeakToSummit.pl -p 0.05 -original -x shM14/shM14_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12/HepG2_shM14_m6a.bed12
exomePeakToSummit.pl -p 0.05 -original -x shM3/shM3_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12/HepG2_shM3_m6a.bed12
exomePeakToSummit.pl -p 0.05 -original -x shWTAP/shWTAP_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12/HepG2_shWTAP_m6a.bed12

### bed6
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6
exomePeakToSummit.pl -p 0.05 -x shCont/shCont_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6/HepG2_shCont_m6a.bed6
exomePeakToSummit.pl -p 0.05 -x shSetD2/shSetD2_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6/HepG2_shSetD2_m6a.bed6
exomePeakToSummit.pl -p 0.05 -x shM14/shM14_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6/HepG2_shM14_m6a.bed6
exomePeakToSummit.pl -p 0.05 -x shM3/shM3_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6/HepG2_shM3_m6a.bed6
exomePeakToSummit.pl -p 0.05 -x shWTAP/shWTAP_m6A_rep1-2-3/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6/HepG2_shWTAP_m6a.bed6

### identify writer targets
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12
awk '{if($15<(1/2)) {for(i=1;i<12;i++) {printf("%s\t",$i);} printf("%s", $12); printf "\n";}}' ./../xls/allPeak/HepG2_m6a_peak_-F0.5_FC.txt > HepG2_m6a_shCont_M14_dependent.bed12
bed2overlap.pl -split -f 0.5 -s -aOver -a HepG2_shSetD2_m6a.bed12 -b HepG2_m6a_shCont_M14_dependent.bed12 -o ./HepG2_m6a_shSetD2_M14_dependent.bed12
exomePeakToSummit.pl -p 0.05 --name shCont_M14_m6a -b HepG2_m6a_shCont_M14_dependent.bed12 -o ./../bed6/HepG2_m6a_shCont_M14_dependent.bed6
exomePeakToSummit.pl -p 0.05 --name shSetD2_M14_m6a -b HepG2_m6a_shSetD2_M14_dependent.bed12 -o ./../bed6/HepG2_m6a_shSetD2_M14_dependent.bed6

awk '{if($16<(1/2)) {for(i=1;i<12;i++) {printf("%s\t",$i);} printf("%s", $12); printf "\n";}}' ./../xls/allPeak/HepG2_m6a_peak_-F0.5_FC.txt > HepG2_m6a_shCont_M3_dependent.bed12
bed2overlap.pl -split -f 0.5 -s -aOver -a HepG2_shSetD2_m6a.bed12 -b HepG2_m6a_shCont_M3_dependent.bed12 -o ./HepG2_m6a_shSetD2_M3_dependent.bed12
exomePeakToSummit.pl -p 0.05 --name shCont_M3_m6a -b HepG2_m6a_shCont_M3_dependent.bed12 -o ./../bed6/HepG2_m6a_shCont_M3_dependent.bed6
exomePeakToSummit.pl -p 0.05 --name shSetD2_M3_m6a -b HepG2_m6a_shSetD2_M3_dependent.bed12 -o ./../bed6/HepG2_m6a_shSetD2_M3_dependent.bed6

awk '{if($17<(1/2)) {for(i=1;i<12;i++) {printf("%s\t",$i);} printf("%s", $12); printf "\n";}}' ./../xls/allPeak/HepG2_m6a_peak_-F0.5_FC.txt > HepG2_m6a_shCont_WTAP_dependent.bed12
bed2overlap.pl -split -f 0.5 -s -aOver -a HepG2_shSetD2_m6a.bed12 -b HepG2_m6a_shCont_WTAP_dependent.bed12 -o ./HepG2_m6a_shSetD2_WTAP_dependent.bed12
exomePeakToSummit.pl -p 0.05 --name shCont_WTAP_m6a -b HepG2_m6a_shCont_WTAP_dependent.bed12 -o ./../bed6/HepG2_m6a_shCont_WTAP_dependent.bed6
exomePeakToSummit.pl -p 0.05 --name shSetD2_WTAP_m6a -b HepG2_m6a_shSetD2_WTAP_dependent.bed12 -o ./../bed6/HepG2_m6a_shSetD2_WTAP_dependent.bed6

###draw bin distribution based on count and bed12 for writer targets

bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_M14_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_M14_dependent.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_M14_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_M14_dependent.bed12bin
paste HepG2_m6a_shCont_M14_dependent.bed12bin HepG2_m6a_shSetD2_M14_dependent.bed12bin | cut -f 1,2,3,6 > HepG2_m6a_M14_dependent.bed12bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_M14_dependent.bed12bin
rm -f HepG2_m6a_shCont_M14_dependent.bed12bin HepG2_m6a_shSetD2_M14_dependent.bed12bin

bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_M3_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_M3_dependent.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_M3_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_M3_dependent.bed12bin
paste HepG2_m6a_shCont_M3_dependent.bed12bin HepG2_m6a_shSetD2_M3_dependent.bed12bin | cut -f 1,2,3,6 > HepG2_m6a_M3_dependent.bed12bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_M3_dependent.bed12bin
rm -f HepG2_m6a_shCont_M3_dependent.bed12bin HepG2_m6a_shSetD2_M3_dependent.bed12bin


bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_WTAP_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_WTAP_dependent.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_WTAP_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_WTAP_dependent.bed12bin
paste HepG2_m6a_shCont_WTAP_dependent.bed12bin HepG2_m6a_shSetD2_WTAP_dependent.bed12bin | cut -f 1,2,3,6 > HepG2_m6a_WTAP_dependent.bed12bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_WTAP_dependent.bed12bin
rm -f HepG2_m6a_shCont_WTAP_dependent.bed12bin HepG2_m6a_shSetD2_WTAP_dependent.bed12bin


###draw bin distribution based on count and bed6 for writer targets
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_M14_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_M14_dependent.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_M14_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_M14_dependent.bed6bin
paste HepG2_m6a_shCont_M14_dependent.bed6bin HepG2_m6a_shSetD2_M14_dependent.bed6bin | cut -f 1,2,3,6 > HepG2_m6a_M14_dependent.bed6bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_M14_dependent.bed6bin
rm -f HepG2_m6a_shCont_M14_dependent.bed6bin HepG2_m6a_shSetD2_M14_dependent.bed6bin

bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_M3_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_M3_dependent.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_M3_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_M3_dependent.bed6bin
paste HepG2_m6a_shCont_M3_dependent.bed6bin HepG2_m6a_shSetD2_M3_dependent.bed6bin | cut -f 1,2,3,6 > HepG2_m6a_M3_dependent.bed6bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_M3_dependent.bed6bin
rm -f HepG2_m6a_shCont_M3_dependent.bed6bin HepG2_m6a_shSetD2_M3_dependent.bed6bin


bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_WTAP_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_WTAP_dependent.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_WTAP_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_WTAP_dependent.bed6bin
paste HepG2_m6a_shCont_WTAP_dependent.bed6bin HepG2_m6a_shSetD2_WTAP_dependent.bed6bin | cut -f 1,2,3,6 > HepG2_m6a_WTAP_dependent.bed6bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_WTAP_dependent.bed6bin
rm -f HepG2_m6a_shCont_WTAP_dependent.bed6bin HepG2_m6a_shSetD2_WTAP_dependent.bed6bin


### identify non writer targets
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12
cat HepG2_m6a_shCont_M14_dependent.bed12 HepG2_m6a_shCont_M3_dependent.bed12 HepG2_m6a_shCont_WTAP_dependent.bed12 | sort -t $'\t' -k1,1V -k2,2n | uniq > HepG2_shCont_allWriter_targets.bed12

bed2exclude.pl -split -s -a HepG2_shCont_m6a.bed12 -b HepG2_shCont_allWriter_targets.bed12 -o ./HepG2_m6a_shCont_nonWriter_targets.bed12
bed2overlap.pl -split -f 0.5 -s -aOver -a HepG2_shSetD2_m6a.bed12 -b HepG2_m6a_shCont_nonWriter_targets.bed12 -o ./HepG2_m6a_shSetD2_nonWriter_targets.bed12
exomePeakToSummit.pl -p 0.05 --name shCont_non_writer_m6a -b HepG2_m6a_shCont_nonWriter_targets.bed12 -o ./../bed6/HepG2_m6a_shCont_nonWriter_targets.bed6
exomePeakToSummit.pl -p 0.05 --name shSetD2_non_writer_m6a -b HepG2_m6a_shSetD2_nonWriter_targets.bed12 -o ./../bed6/HepG2_m6a_shSetD2_nonWriter_targets.bed6

###draw bin distribution based on count and bed12 for  non-writer targets
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_nonWriter_targets.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_nonWriter_targets.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_nonWriter_targets.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_nonWriter_targets.bed12bin
paste HepG2_m6a_shCont_nonWriter_targets.bed12bin HepG2_m6a_shSetD2_nonWriter_targets.bed12bin | cut -f 1,2,3,6 > HepG2_m6a_nonWriter_dependent.bed12bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_nonWriter_dependent.bed12bin
rm -f HepG2_m6a_shCont_nonWriter_targets.bed12bin HepG2_m6a_shSetD2_nonWriter_targets.bed12bin


###draw bin distribution based on count and bed6 for  non-writer targets
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shCont_nonWriter_targets.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shCont_nonWriter_targets.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_m6a_shSetD2_nonWriter_targets.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_m6a_shSetD2_nonWriter_targets.bed6bin
paste HepG2_m6a_shCont_nonWriter_targets.bed6bin HepG2_m6a_shSetD2_nonWriter_targets.bed6bin | cut -f 1,2,3,6 > HepG2_m6a_nonWriter_dependent.bed6bin
sed  -i '1i region\tbin\tshCont\tshSetD2' HepG2_m6a_nonWriter_dependent.bed6bin
rm -f HepG2_m6a_shCont_nonWriter_targets.bed6bin HepG2_m6a_shSetD2_nonWriter_targets.bed6bin


###draw all bed12 peak distribution
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shCont_m6a.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shCont_m6a.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shSetD2_m6a.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shSetD2_m6a.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shM14_m6a.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shM14_m6a.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shM3_m6a.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shM3_m6a.bed12bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shWTAP_m6a.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shWTAP_m6a.bed12bin
paste HepG2_shCont_m6a.bed12bin HepG2_shSetD2_m6a.bed12bin HepG2_shM14_m6a.bed12bin HepG2_shM3_m6a.bed12bin HepG2_shWTAP_m6a.bed12bin | cut -f 1,2,3,6,9,12,15 > HepG2_m6a.bed12bin
sed  -i '1i region\tbin\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' HepG2_m6a.bed12bin
rm -f HepG2_shCont_m6a.bed12bin HepG2_shSetD2_m6a.bed12bin HepG2_shM14_m6a.bed12bin HepG2_shM3_m6a.bed12bin HepG2_shWTAP_m6a.bed12bin

###draw all bed6 peak distribution
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shCont_m6a.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shCont_m6a.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shSetD2_m6a.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shSetD2_m6a.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shM14_m6a.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shM14_m6a.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shM3_m6a.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shM3_m6a.bed6bin
bedBinDistribution.pl -strand -smooth move -t count --input HepG2_shWTAP_m6a.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.mRNA.longest.exon.bed6 -o ./HepG2_shWTAP_m6a.bed6bin
paste HepG2_shCont_m6a.bed6bin HepG2_shSetD2_m6a.bed6bin HepG2_shM14_m6a.bed6bin HepG2_shM3_m6a.bed6bin HepG2_shWTAP_m6a.bed6bin | cut -f 1,2,3,6,9,12,15 > HepG2_m6a.bed6bin
sed  -i '1i region\tbin\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' HepG2_m6a.bed6bin
rm -f HepG2_shCont_m6a.bed6bin HepG2_shSetD2_m6a.bed6bin HepG2_shM14_m6a.bed6bin HepG2_shM3_m6a.bed6bin HepG2_shWTAP_m6a.bed6bin


#### SetD2 dependent m6a sites
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed12
awk '{if($14<(1/2)) {for(i=1;i<12;i++) {printf("%s\t",$i);} printf("%s", $12); printf "\n";}}' ./../xls/allPeak/HepG2_m6a_peak_-F0.5_FC.txt > ./HepG2_m6a_shCont_SetD2_dependent.bed12

#### gene type counts and region counts of SetD2 dependent m6a sites
geneDistribution.pl -strand --input ./HepG2_m6a_shCont_SetD2_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.all.longest.exon.bed6 -o ./HepG2_m6a_shCont_SetD2_dependent.gene
sed  -i '1i geneType\tpeakNumber' ./HepG2_m6a_shCont_SetD2_dependent.gene
regionDistribution.pl -strand --input ./HepG2_m6a_shCont_SetD2_dependent.bed12 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.all.longest.exon.bed6 -o ./HepG2_m6a_shCont_SetD2_dependent.region
sed  -i '1i region\tpeakNumber\tenrichment' ./HepG2_m6a_shCont_SetD2_dependent.region


cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/bed6
awk '{if($14<(1/2)) {for(i=1;i<12;i++) {printf("%s\t",$i);} printf("%s", $12); printf "\n";}}' ./../xls/allPeak/HepG2_m6a_peak_-F0.5_FC.txt > ./HepG2_m6a_shCont_SetD2_dependent.bed12
exomePeakToSummit.pl -p 0.05 --name SetD2_dependent_m6a -b ./../bed12/HepG2_m6a_shCont_SetD2_dependent.bed12 -o ./HepG2_m6a_shCont_SetD2_dependent.bed6

rm -f HepG2_m6a_shCont_SetD2_dependent.bed12
#### gene type counts and region counts of SetD2 dependent m6a sites
geneDistribution.pl -strand --input ./HepG2_m6a_shCont_SetD2_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.all.longest.exon.bed6 -o ./HepG2_m6a_shCont_SetD2_dependent.gene
sed  -i '1i geneType\tpeakNumber' ./HepG2_m6a_shCont_SetD2_dependent.gene
regionDistribution.pl -strand --input ./HepG2_m6a_shCont_SetD2_dependent.bed6 -bed6 /data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.v24lift37.annotation.all.longest.exon.bed6 -o ./HepG2_m6a_shCont_SetD2_dependent.region
sed  -i '1i region\tpeakNumber\tenrichment' ./HepG2_m6a_shCont_SetD2_dependent.region
