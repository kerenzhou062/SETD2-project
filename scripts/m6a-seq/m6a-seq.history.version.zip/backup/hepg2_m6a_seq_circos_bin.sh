#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/circos
exomePeakToCircos.pl -g human -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shCont/shCont_m6A/peak.xls -o HepG2_m6a_shCont_circos.txt
exomePeakToCircos.pl -g human -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shSetD2/shSetD2_m6A/peak.xls -o HepG2_m6a_shSetD2_circos.txt
exomePeakToCircos.pl -g human -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM14/shM14_m6A/peak.xls -o HepG2_m6a_shM14_circos.txt
exomePeakToCircos.pl -g human -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shM3/shM3_m6A/peak.xls -o HepG2_m6a_shM3_circos.txt
exomePeakToCircos.pl -g human -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/human_hg19_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/HepG2_m6A-seq/shWTAP/shWTAP_m6A/peak.xls -o HepG2_m6a_shWTAP_circos.txt

paste HepG2_m6a_shCont_circos.txt HepG2_m6a_shSetD2_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > HepG2_m6a_shSetD2_FC_circos.txt
paste HepG2_m6a_shCont_circos.txt HepG2_m6a_shM14_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > HepG2_m6a_shM14_FC_circos.txt
paste HepG2_m6a_shCont_circos.txt HepG2_m6a_shM3_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > HepG2_m6a_shM3_FC_circos.txt
paste HepG2_m6a_shCont_circos.txt HepG2_m6a_shWTAP_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > HepG2_m6a_shWTAP_FC_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/circos/conf/line/bin
circos -conf line.hs1.shCont_vs_shSetD2.conf > /dev/null 2>&1 &
circos -conf line.hs1.shCont_vs_all.conf > /dev/null 2>&1 &
circos -conf line.hs1.FC_all.conf > /dev/null 2>&1 &

#cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/circos/conf/histogram/bin
#circos -conf histogram.hs1.shCont_vs_shSetD2.conf > /dev/null 2>&1 &
#circos -conf histogram.shCont_vs_shSetD2.conf > /dev/null 2>&1 &
#
#cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/circos/conf/heatmap/bin
#circos -conf heatmap.shCont_vs_shSetD2.conf > /dev/null 2>&1 &
#
#cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/circos/conf/line/bin
#circos -conf line.hs1.shCont_vs_shSetD2.conf > /dev/null 2>&1 &

