#!/bin/sh

## motif
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/HepG2/
rm -rf ./motif
mkdir ./motif
mkdir ./motif/HepG2_shCont_m6a
mkdir ./motif/HepG2_shSetD2_m6a
mkdir ./motif/HepG2_m6a_shCont_SetD2_dependent

exomePeakToSummit.pl -p 0.05 -b ./bed12/HepG2_m6a_shCont_SetD2_dependent.bed12 -o ./bed6/HepG2_m6a_shCont_SetD2_dependent.bed6


findMotifsGenome.pl ./bed6/HepG2_shCont_m6a.bed6 hg19 ./motif/HepG2_shCont_m6a -rna -size 200 -len 7 > ./motif/HepG2_shCont_m6a.log 2>&1 &
findMotifsGenome.pl ./bed6/HepG2_shSetD2_m6a.bed6 hg19 ./motif/HepG2_shSetD2_m6a -rna -size 200 -len 7 > ./motif/HepG2_shSetD2_m6a.log 2>&1 &
findMotifsGenome.pl ./bed6/HepG2_m6a_shCont_SetD2_dependent.bed6 hg19 ./motif/HepG2_m6a_shCont_SetD2_dependent -rna -size 200 -len 7 > ./motif/HepG2_m6a_shCont_SetD2_dependent.log 2>&1 &
