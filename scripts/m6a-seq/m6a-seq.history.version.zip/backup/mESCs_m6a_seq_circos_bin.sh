#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mESCs/circos
exomePeakToCircos.pl -g mouse -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/mouse_ESCs_m6A-seq/Ctrl_D0/Ctrl_D0_m6A/peak.xls -o mESCs_m6a_shCont_D0_circos.txt
exomePeakToCircos.pl -g mouse -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/mouse_ESCs_m6A-seq/Ctrl_D6/Ctrl_D6_m6A/peak.xls -o mESCs_m6a_shCont_D6_circos.txt
exomePeakToCircos.pl -g mouse -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/mouse_ESCs_m6A-seq/SetD2-KD_D0/SetD2-KD_D0_m6A/peak.xls -o mESCs_m6a_shSetD2_D0_circos.txt
exomePeakToCircos.pl -g mouse -span 400000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/mouse_ESCs_m6A-seq/SetD2-KD_D6/SetD2-KD_D6_m6A/peak.xls -o mESCs_m6a_shSetD2_D6_circos.txt


paste mESCs_m6a_shCont_D0_circos.txt mESCs_m6a_shCont_D6_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > mESCs_m6a_shCont_D6vsD0_FC_circos.txt
paste mESCs_m6a_shCont_D0_circos.txt mESCs_m6a_shSetD2_D0_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > mESCs_m6a_shSetD2vsshCont_D0_FC_circos.txt
paste mESCs_m6a_shCont_D0_circos.txt mESCs_m6a_shSetD2_D6_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > mESCs_m6a_shSetD2vsshCont_D6vsD0_FC_circos.txt
paste mESCs_m6a_shCont_D6_circos.txt mESCs_m6a_shSetD2_D6_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > mESCs_m6a_shSetD2vsshCont_D6_FC_circos.txt
paste mESCs_m6a_shSetD2_D0_circos.txt mESCs_m6a_shSetD2_D6_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > mESCs_m6a_shSetD2_D6vsD0_FC_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mESCs/circos/conf/line/bin
circos -conf line.mm1.FC_all.conf > /dev/null 2>&1 &
circos -conf line.mm1.shSetD2vsshCont_D0_D6_FC.conf > /dev/null 2>&1 &
circos -conf line.mm1.shSetD2vsshCont_D6vsD0_FC.conf > /dev/null 2>&1 &
