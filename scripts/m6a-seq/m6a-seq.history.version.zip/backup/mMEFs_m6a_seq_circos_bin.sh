#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mMEFs/circos
exomePeakToCircos.pl -g mouse -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/mouse_MEFs_m6A-seq/SetD2-WT_NA/SetD2-WT_NA_m6A/peak.xls -o mMEFs_m6a_shCont_circos.txt
exomePeakToCircos.pl -g mouse -span 1000000 -gs /data/zhoukr/reference/genome/genome_size/nature/mouse_mm10_chrsize.txt -x /data/zhoukr/hhl_setd2_m6a/mouse_MEFs_m6A-seq/SetD2-KO_NA/SetD2-KO_NA_m6A/peak.xls -o mMEFs_m6a_shSetD2_circos.txt


paste mMEFs_m6a_shCont_circos.txt mMEFs_m6a_shSetD2_circos.txt | cut -f 1,2,3,4,8 | awk 'BEGIN{OFS="\t";};{$4=$4+1; $5=$5+1; FC=log($5/$4)/log(2); print $1,$2,$3,FC;}' > mMEFs_m6a_shSetD2_FC_circos.txt

cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mMEFs/circos/conf/line/bin
circos -conf line.mm1.FC_all.conf > /dev/null 2>&1 &
