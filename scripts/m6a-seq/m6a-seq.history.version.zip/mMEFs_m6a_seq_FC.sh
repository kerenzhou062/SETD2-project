#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/mouse_MEFs_m6A-seq

## xls
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mMEFs/xls
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mMEFs/xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x SetD2-WT_NA/SetD2-WT_NA_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mMEFs/xls/mMEFs_shCont_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x SetD2-KO_NA/SetD2-KO_NA_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mMEFs/xls/mMEFs_shSetD2_m6a.xls

### peak fold_enrichment
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/mMEFs/xls
mkdir allPeak
# overlapped peak

exomePeakFC.pl -cutoff 0.1 -F 0.5 -x mMEFs_shCont_m6a.xls mMEFs_shSetD2_m6a.xls -o ./temp.tmp
awk 'BEGIN{OFS="\t";FS="\t"; print "chr\tchromStart\tchromEnd\tid\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2"; }
ARGIND==1{split($4,geneIdI,":");split(geneIdI[1],geneIdInfo,".");geneIdi=geneIdInfo[1];geneNamei=geneIdI[2];hashGeneIdName[geneIdi]=geneNamei;}
ARGIND==2{split($4,geneIdH,".");geneIdh=geneIdH[1]; if (geneIdh in hashGeneIdName){geneNameh=hashGeneIdName[geneIdh]}else{geneNameh="-"};$4=$4"\t"geneNameh; print $0}' \
/data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.vM9.annotation.all.longest.exon.bed6 ./temp.tmp > ./allPeak/mMEFs_shCont_vs_shSetD2_m6a_peak_-F0.5_FC.txt

exomePeakFC.pl -cutoff 0.1 -log 2 -F 0.5 -x mMEFs_shCont_m6a.xls mMEFs_shSetD2_m6a.xls -o ./temp.tmp
awk 'BEGIN{OFS="\t";FS="\t"; print "chr\tchromStart\tchromEnd\tid\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2"; }
ARGIND==1{split($4,geneIdI,":");split(geneIdI[1],geneIdInfo,".");geneIdi=geneIdInfo[1];geneNamei=geneIdI[2];hashGeneIdName[geneIdi]=geneNamei;}
ARGIND==2{split($4,geneIdH,".");geneIdh=geneIdH[1]; if (geneIdh in hashGeneIdName){geneNameh=hashGeneIdName[geneIdh]}else{geneNameh="-"};$4=$4"\t"geneNameh; print $0}' \
/data/zhoukr/hhl_setd2_m6a/reference/annotation/gencode.vM9.annotation.all.longest.exon.bed6 ./temp.tmp > ./allPeak/mMEFs_shCont_vs_shSetD2_m6a_peak_-F0.5_FC_log2.txt

rm -f ./temp.tmp
