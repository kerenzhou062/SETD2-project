#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq

## xls
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shCont/shCont_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls/Hela_shCont_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shSetD2/shSetD2_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls/Hela_shSetD2_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shM14/shM14_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls/Hela_shM14_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shM3/shM3_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls/Hela_shM3_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shWTAP/shWTAP_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls/Hela_shWTAP_m6a.xls

### peak fold_enrichment
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/xls
mkdir allPeak
mkdir overlappedPeak
# all peak
exomePeakFC.pl -FE -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_FoldEnrichment.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_FoldEnrichment.txt

exomePeakFC.pl -FE -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_-F0.5_FoldEnrichment.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_-F0.5_FoldEnrichment.txt

exomePeakFC.pl -FE -log 2 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_FoldEnrichment_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_FoldEnrichment_log2.txt

exomePeakFC.pl -FE -log 2 -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_-F0.5_FoldEnrichment_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_-F0.5_FoldEnrichment_log2.txt

exomePeakFC.pl -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_FC.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_FC.txt

exomePeakFC.pl -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_-F0.5_FC.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_-F0.5_FC.txt

exomePeakFC.pl -log 2 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_FC_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_FC_log2.txt

exomePeakFC.pl -log 2 -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./allPeak/Hela_m6a_peak_-F0.5_FC_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./allPeak/Hela_m6a_peak_-F0.5_FC_log2.txt



# overlapped peak
exomePeakFC.pl -overlap 0 1 1 1 1 -FE -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_FoldEnrichment.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_FoldEnrichment.txt

exomePeakFC.pl -overlap 0 1 1 1 1 -FE -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_-F0.5_FoldEnrichment.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_-F0.5_FoldEnrichment.txt

exomePeakFC.pl -overlap 0 1 1 1 1 -FE -log 2 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_FoldEnrichment_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_FoldEnrichment_log2.txt

exomePeakFC.pl -overlap 0 1 1 1 1 -FE -log 2 -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_-F0.5_FoldEnrichment_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_-F0.5_FoldEnrichment_log2.txt

exomePeakFC.pl -overlap 0 1 1 1 1 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_FC.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_FC.txt

exomePeakFC.pl -overlap 0 1 1 1 1 -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_-F0.5_FC.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_-F0.5_FC.txt

exomePeakFC.pl -overlap 0 1 1 1 1 -log 2 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_FC_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_FC_log2.txt

exomePeakFC.pl -overlap 0 1 1 1 1 -log 2 -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./overlappedPeak/Hela_m6a_peak_-F0.5_FC_log2.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./overlappedPeak/Hela_m6a_peak_-F0.5_FC_log2.txt

