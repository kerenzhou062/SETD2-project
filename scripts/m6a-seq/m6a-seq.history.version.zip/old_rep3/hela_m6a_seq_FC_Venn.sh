#!/bin/sh

cd /data/zhoukr/hhl_setd2_m6a/Hela_m6A-seq

## xls
rm -rf /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn
mkdir /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn
exomePeakToSummit.pl -p 0.05 -original -format xls -x shCont/shCont_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn/Hela_shCont_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shSetD2/shSetD2_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn/Hela_shSetD2_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shM14/shM14_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn/Hela_shM14_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shM3/shM3_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn/Hela_shM3_m6a.xls
exomePeakToSummit.pl -p 0.05 -original -format xls -x shWTAP/shWTAP_m6A/peak.xls -o /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn/Hela_shWTAP_m6a.xls

### peak fold_enrichment
cd /data/zhoukr/hhl_setd2_m6a/analysis/m6a-seq/Hela/venn
# all peak
exomePeakFC.pl -F 0.5 -x Hela_shCont_m6a.xls Hela_shSetD2_m6a.xls Hela_shM14_m6a.xls Hela_shM3_m6a.xls Hela_shWTAP_m6a.xls -o ./Hela_m6a_peak_-F0.5_FC.txt
sed -i '1i chr\tchromStart\tchromEnd\tname\tscore\tstrand\tthickStart\tthickEnd\titemRgb\tblockCount\tblockSizes\tblockStarts\tshCont\tshSetD2\tshM14\tshM3\tshWTAP' ./Hela_m6a_peak_-F0.5_FC.txt

awk 'BEGIN{OFS="\t";};{ if(NR>1){ cutoff=1/2;if($14<cutoff && $13 > 3){ gsub(/\.[0-9]+/,"" ,$4);print $4; } } }' ./Hela_m6a_peak_-F0.5_FC.txt | sort | uniq > ./Hela_shSetD2_-F0.5_FC_gene.txt
awk 'BEGIN{OFS="\t";};{ if(NR>1){ cutoff=1/2;if($15<cutoff && $13 > 3){ gsub(/\.[0-9]+/,"" ,$4);print $4; } } }' ./Hela_m6a_peak_-F0.5_FC.txt | sort | uniq > ./Hela_shM14_-F0.5_FC_gene.txt
awk 'BEGIN{OFS="\t";};{ if(NR>1){ cutoff=1/2;if($16<cutoff && $13 > 3){ gsub(/\.[0-9]+/,"" ,$4);print $4; } } }' ./Hela_m6a_peak_-F0.5_FC.txt | sort | uniq > ./Hela_shM3_-F0.5_FC_gene.txt
awk 'BEGIN{OFS="\t";};{ if(NR>1){ cutoff=1/2;if($17<cutoff && $13 > 3){ gsub(/\.[0-9]+/,"" ,$4);print $4; } } }' ./Hela_m6a_peak_-F0.5_FC.txt | sort | uniq > ./Hela_shWTAP_-F0.5_FC_gene.txt
