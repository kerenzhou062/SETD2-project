#!/usr/bin/perl

use strict;
use warnings;
use POSIX;
use Pod::Usage;
use Getopt::Long qw(GetOptions);
###develop by K.R.Chow, designed for computing the distribution patterns on transcripts.

Getopt::Long::Configure(qw(posix_default no_ignore_case));  # allow the program accept the command-line without order.
pod2usage(1) if (&check_command_line(4));

my $help   = 0;
my $man    = 0;
my $annotationFile;
my $bedFile;
my $output = './distributionResult.txt';
my $binSize = 100;
my $smooth;
my $sort;
my $span = 5;
my $verbose;

GetOptions (
  "a|annotation=s"                   =>\$annotationFile,
  "b|bed=s"                          =>\$bedFile,
  "o|output=s"                       =>\$output,
  "h|help"                           =>\$help,
  "s|size"                           =>\$binSize,
  "smooth"                           =>\$smooth,
  "sort"                             =>\$sort,
  "span"                             =>\$span,
  "verbose"                          =>\$verbose,
  "man"                              =>\$man
) or pod2usage(2); pod2usage(1) if $help; pod2usage(-verbose => 2) if $man;

($annotationFile, undef) = split ("\n", `readlink -f $annotationFile`); ## convert ralative path to ablolute path
($bedFile, undef)        = split ("\n", `readlink -f $bedFile`);
($output, undef)         = split ("\n", `readlink -f $output`);

my @outputPath = split (/\\|\//, $output); splice (@outputPath, -1, 1);
my $outputPath  = join "/", @outputPath;

my %hashPeak;
my $totalPeak  = 0;

`find $outputPath -name "*.tmp" | rm -f`;

my $tempCenter = $outputPath .'/'. rand(1000000) .'.tmp';
open (PEAK, "<$bedFile") or die "Cannot open file: $bedFile, $!\n";
open (TEMP, ">$tempCenter") or die "Cannot open file: $tempCenter, $!\n";
while (my $line=<PEAK>) {
  chomp($line);
  my @lineContents = split("\t", $line);
  my $pcStart      = int( ($lineContents[1] + $lineContents[2]) / 2 );
  my $pcEnd        = $pcStart + 1;
  my $peakKey      = join("\t", @lineContents[0..2]) ."\t". $lineContents[5];
  ### judge if the bed peaks contain any duplicates
  if (exists($hashPeak{$peakKey})) {
    next;
  }else{
    $hashPeak{$peakKey}++;
  }
  $totalPeak++;
  $lineContents[3] = 'peak'. $totalPeak;
  print TEMP $lineContents[0], "\t", $pcStart, "\t", $pcEnd, "\t", join("\t", @lineContents[3..5]),"\n";
}
close(PEAK);
close(TEMP);

my $intersectTemp = $outputPath .'/'. rand(1000000) .'.tmp';
if (defined($sort)) {
  `sort -t \$'\t' -k 1,1V -k 2,2n $tempCenter -o $tempCenter`;
  `sort -t \$'\t' -k 1,1V -k 2,2n $annotationFile -o $annotationFile`;
}

`bedtools intersect -wb -s -split -a $tempCenter -b $annotationFile > $intersectTemp`;

my %hashPeakBin;
open(INTERSECT,"<$intersectTemp") or die "can't open $intersectTemp, $!\n";
while (my $line=<INTERSECT>) {
  chomp($line);
  my @lineContents    = split("\t", $line);
  my $pcEnd           = $lineContents[2];
  my $peakID          = $lineContents[3];

  my $txStart         = $lineContents[7];
  my $txEnd           = $lineContents[8];
  my $txStrand        = $lineContents[11];
  my $cdsStart        = $lineContents[12];
  my $cdsEnd          = $lineContents[13];
  my $blockLengthCol = $lineContents[16]; $blockLengthCol =~ s/,$//;
  my $blockStartCol  = $lineContents[17]; $blockStartCol =~ s/,$//;

  my @blockLengthList = split(',',$blockLengthCol);
  my @blockStartList  = split(',',$blockStartCol);
  my $blockNumber     = scalar (@blockLengthList);

  my $pcEndBlockTag;
  my $cdsStartBlockTag;
  my $cdsEndBlcokTag;
  my $pcShiftRe  = 0;
  my $regionSize = 0;
  my $bin;

  for (my $i = 0; $i < $blockNumber; $i++) {
    my $blockStart = $txStart + $blockStartList[$i];
    my $blockEnd   = $blockStart + $blockLengthList[$i];
    if ($pcEnd >= $blockStart and $pcEnd <= $blockEnd) {
      $pcEndBlockTag = $i;
    }
    if ($cdsStart >= $blockStart and $cdsStart <= $blockEnd) {
      $cdsStartBlockTag = $i;
    }
    if ($cdsEnd >= $blockStart and $cdsEnd <= $blockEnd) {
      $cdsEndBlcokTag = $i;
    }
  }

  next if (! defined($pcEndBlockTag));

  if ($pcEnd <= $cdsStart) {
    if ($pcEndBlockTag == $cdsStartBlockTag) {# 5UTR(pcEnd, cdsStart)
      for (my $i = 0; $i <= $cdsStartBlockTag; $i++) {
        my $blockStart = $txStart + $blockStartList[$i];
        if ($i == $pcEndBlockTag) {
          $pcShiftRe  = $pcEnd - $blockStart + $regionSize;
          $regionSize += $cdsStart - $blockStart + 1;
        }else{
          $regionSize += $blockLengthList[$i];
        }
      }
    }else{# 5UTR(pcEnd)...(cdsStart)
      for (my $i = 0; $i <= $cdsStartBlockTag; $i++) {
        my $blockStart = $txStart + $blockStartList[$i];
        if ($i == $pcEndBlockTag) {
          $pcShiftRe  = $pcEnd - $blockStart + $regionSize;
          $regionSize += $blockLengthList[$i];
        }elsif ($i == $cdsStartBlockTag) {
          $regionSize += $cdsStart - $blockStart + 1;
        }else{
          $regionSize += $blockLengthList[$i];
        }
      }
    }
    if ($txStrand eq '+') {
      $bin = ceil( ($pcShiftRe / $regionSize) * 100 );
      $hashPeakBin{$peakID}->{'5UTR'}->{$bin}++;
    }else{
      $bin = ceil( ( ($regionSize - $pcShiftRe + 1) / $regionSize) * 100 );
      $hashPeakBin{$peakID}->{'3UTR'}->{$bin}++;
    }
  }elsif ($pcEnd > $cdsStart and $pcEnd <= $cdsEnd) {
    if ($cdsStartBlockTag == $pcEndBlockTag and $pcEndBlockTag == $cdsEndBlcokTag) {# 5UTR(cdsStart, pcEnd, $cdsEnd)3UTR
      $pcShiftRe  = $pcEnd - $cdsStart;
      $regionSize = $cdsEnd - $cdsStart;
    }elsif ($cdsStartBlockTag == $pcEndBlockTag and $pcEndBlockTag < $cdsEndBlcokTag) {# 5UTR(cdsStart, pcEnd)...(cdsEnd)3UTR
      for (my $i = $cdsStartBlockTag; $i <= $cdsEndBlcokTag; $i++) {
        my $blockStart = $txStart + $blockStartList[$i];
        my $blockEnd   = $blockStart + $blockLengthList[$i];
        if ($i == $cdsStartBlockTag) {
          $pcShiftRe  = $pcEnd - $cdsStart;
          $regionSize += $blockEnd - $cdsStart;
        }elsif ($i == $cdsEndBlcokTag) {
          $regionSize += $cdsEnd - $blockStart;
        }else{
          $regionSize += $blockLengthList[$i];
        }
      }
    }elsif ($cdsStartBlockTag < $pcEndBlockTag and $pcEndBlockTag < $cdsEndBlcokTag) {# 5UTR(cdsStart)...(pcEnd)...(cdsEnd)3UTR
      for (my $i = $cdsStartBlockTag; $i <= $cdsEndBlcokTag; $i++) {
        my $blockStart = $txStart + $blockStartList[$i];
        my $blockEnd   = $blockStart + $blockLengthList[$i];
        if ($i == $cdsStartBlockTag) {
          $regionSize += $blockEnd - $cdsStart;
        }elsif ($i == $pcEndBlockTag) {
          $pcShiftRe = $pcEnd - $blockStart + $regionSize;
          $regionSize += $blockLengthList[$i];
        }elsif ($i == $cdsEndBlcokTag) {
          $regionSize += $cdsEnd - $blockStart;
        }else{
          $regionSize += $blockLengthList[$i];
        }
      }
    }else{# 5UTR(cdsStart)...(pcEnd, cdsEnd)3UTR
      for (my $i = $cdsStartBlockTag; $i <= $cdsEndBlcokTag; $i++) {
        my $blockStart = $txStart + $blockStartList[$i];
        my $blockEnd   = $blockStart + $blockLengthList[$i];
        if ($i == $cdsStartBlockTag) {
          $regionSize += $blockEnd - $cdsStart;
        }elsif ($i == $cdsEndBlcokTag) {
          $pcShiftRe  = $pcEnd - $blockStart + $regionSize;
          $regionSize += $cdsEnd - $blockStart;
        }else{
          $regionSize += $blockLengthList[$i];
        }
      }
    }
    if ($txStrand eq '+') {
      $bin = ceil( ( ($pcShiftRe / $regionSize) * 100) );
      $hashPeakBin{$peakID}->{'CDS'}->{$bin}++;
    }else{
      $bin = ceil( ( ($regionSize - $pcShiftRe + 1) / $regionSize) * 100 );
      $hashPeakBin{$peakID}->{'CDS'}->{$bin}++;
    }
  }else{
    if ($pcEndBlockTag == $cdsEndBlcokTag) {#(cdsEnd, pcEnd)3UTR
      for (my $i = $cdsEndBlcokTag; $i < $blockNumber; $i++) {
        my $blockStart = $txStart + $blockStartList[$i];
        my $blockEnd   = $blockStart + $blockLengthList[$i];
        if ($i == $cdsEndBlcokTag) {
          $pcShiftRe  = $pcEnd - $cdsEnd + 1 + $regionSize;
          $regionSize += $blockEnd - $cdsEnd + 1;
        }else{
          $regionSize += $blockLengthList[$i];
        }
      }
    }else{#(cdsEnd)...(pcEnd)3UTR
      for (my $i = $cdsEndBlcokTag; $i < $blockNumber; $i++) {
        my $blockStart = $txStart + $blockStartList[$i];
        my $blockEnd   = $blockStart + $blockLengthList[$i];
        if ($i == $cdsEndBlcokTag) {
          $regionSize += $blockEnd - $cdsEnd + 1;
        }elsif($i == $pcEndBlockTag){
          $pcShiftRe = $pcEnd - $blockStart + $regionSize;
          $regionSize += $blockLengthList[$i];
        }else{
          $regionSize += $blockLengthList[$i];
        }
      }
    }
    if ($txStrand eq '+') {
      $bin = ceil( ($pcShiftRe / $regionSize) * 100 );
      $hashPeakBin{$peakID}->{'3UTR'}->{$bin}++;
    }else{
      $bin = ceil( ( ($regionSize - $pcShiftRe + 1) / $regionSize) * 100 );
      $hashPeakBin{$peakID}->{'5UTR'}->{$bin}++;
    }
  }
}

my %hashRegionBin;
my @peakIDs = sort keys %hashPeakBin;
foreach my $peakID(@peakIDs) {
  my @regions     = sort keys %{$hashPeakBin{$peakID}};
  my $totalBinHit = 0;
  foreach my $region (@regions) {
    my @bins = sort keys %{$hashPeakBin{$peakID}->{$region}};
    foreach my $bin (@bins) {
      $totalBinHit += $hashPeakBin{$peakID}->{$region}->{$bin};
    }
  }
  my $eachHit = 1 / $totalBinHit;
  foreach my $region (@regions) {
    my @bins = sort keys %{$hashPeakBin{$peakID}->{$region}};
    foreach my $bin (@bins) {
      $hashRegionBin{'count'}->{$region}->{$bin} += $eachHit;
    }
  }
}

`rm -f $tempCenter $intersectTemp`;



my $totalValidPeak = keys %hashPeakBin;
my $DiscardPeakNum = $totalPeak - $totalValidPeak;
my @regions        = ('5UTR', 'CDS', '3UTR');
my $iteration      = 0;
if (defined($verbose)) {
  print STDERR "Discard $DiscardPeakNum peaks which do not appear on blocks from $totalPeak peaks ($bedFile).\n";
}

foreach my $region (@regions) {
  my $binShift = $iteration * 100 + 1;
  for (my $bin = $binShift; $bin < ($binShift + 100); $bin++) {
    my $percentage;
    if (exists ($hashRegionBin{'count'}->{$region}->{$bin - $binShift + 1})) {
      my $binCount = $hashRegionBin{'count'}->{$region}->{$bin - $binShift + 1};
      $percentage = sprintf( "%.2f", ( ( $binCount / $totalValidPeak ) * 100) );
    }else{
      $percentage = 0;
    }
    $hashRegionBin{'percentage'}->{$bin} = $percentage;
  }
  $iteration++;
}

my @ouputValueList;

if (defined($smooth)) {
  my @binValueList;
  foreach my $bin (sort {$a<=>$b} keys %{$hashRegionBin{'percentage'}} ){
    push(@binValueList, $hashRegionBin{'percentage'}->{$bin});
  }
  @ouputValueList = &smooth( \@binValueList, int($span) );
}else{
  foreach my $bin (sort {$a<=>$b} keys %{$hashRegionBin{'percentage'}} ){
    push(@ouputValueList, $hashRegionBin{'percentage'}->{$bin});
  }
}

open (OUT, ">$output") or die "can't open $output, $!\n";
print OUT "region\tbin\tpercentage\n";
for (my $i = 1; $i <= 300; $i++) {
  if ($i >= 1 and $i <= 100) {
    print OUT join ("\t", ('5UTR', $i, $ouputValueList[$i-1])), "\n";
  }elsif ($i >= 101 and $i <= 200) {
    print OUT join ("\t", ('CDS', $i, $ouputValueList[$i-1])), "\n";
  }else{
    print OUT join ("\t", ('3UTR', $i, $ouputValueList[$i-1])), "\n";
  }
}

sub smooth{
  my ($valueListRef, $span) = @_;
  my @movingSmoothValList;
  for (my $i = 0; $i < scalar(@$valueListRef); $i++) {
    my $sum         = 0;
    my $movingValue = 0;
    if ($i < ($span - 1)) {
      for (my $j = 0; $j <= $i; $i++) {
        $sum += $$valueListRef[$j];
      }
      $movingValue = $sum / ($i + 1);
    }else{
      for (my $j = ($i - $span + 1); $j < ($i + 1); $j++){
        $sum += $$valueListRef[$j];
      }
      $movingValue = $sum / $span;
    }
    $movingSmoothValList[$i] = $movingValue;
  }
  return @movingSmoothValList;
}


sub check_command_line{
  my ($arguments_num) = @_;
  if (scalar(@ARGV) < $arguments_num) {
    my %hash_arguments;
    foreach (@ARGV) {
      $hash_arguments{$_} = 1;
    }
    return 0 if (exists($hash_arguments{'-h'}) or exists($hash_arguments{'--help'}) or exists($hash_arguments{'-man'})) or return 1;
  }
}

################# Abbreviations for this script #################
#
# pcStart      = start position of a peak center
# pcEnd        = end position of a peak center
# txStart      = start position of an transcript
# annoEnd      = end position of an transcript
# pcShiftRe    = length that a peak center shifts from the bigining of a transcript region (5'UTR, CDS, or 3'UTR)
# regionSize   = total length for a transcript region
# hashReBinPer = The hash for region->bin->percentage
################# Abbreviations for this script #################

__END__

=head1 NAME

computeBinDistribution.pl @copyright K.R.Chow

=head1 CAUTIONS

If "-s" are not defined, it will be set to "100".

=head1 SYNOPSIS
This script is designed for computing the distribution patterns on transcripts.

computeBinDistribution.pl [options] -a [file] -b[file] -o [file]
 Options:
    -a | --annotation  The annotation file in bed12
    -b | --bed         The input bed file
    -o | --output      The output file name
    -s | --size        The bin size (set 100 by default)
    -smooth            Use moving smooth method (False by default)
    -sort              Sort bed before using bedtools
    -span              The span for smooth (int, 5 by default)
    -h | --help        Brief help message
    -man               Full documentation

=head1 OPTIONS

=over 4

=item B<-h|--help>

computeBinDistribution.pl [options] -a [file] -b[file] -o [file]

=item B<-man>

Prints the manual page and exits.

=back

=head1 DESCRIPTION

B<This program> will compute the distribution patterns on transcripts.

=cut
