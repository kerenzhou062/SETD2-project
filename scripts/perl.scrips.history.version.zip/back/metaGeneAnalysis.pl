#!/usr/bin/perl

use strict;
use warnings;
use POSIX;
use Pod::Usage;
use Getopt::Long qw(GetOptions);
###develop by K.R.Chow, designed for computing the distribution patterns on transcripts.

Getopt::Long::Configure(qw(posix_default no_ignore_case));  # allow the program accept the command-line without order.
pod2usage(1) if (scalar(@ARGV) == 0);

my $help   = 0;
my $man    = 0;
my $features = '5utr,cds,3utr';
my $input;
my $bed12File;
my $bed6File;
my $output = './binResult.txt';
my $binType = 'constant';
my $binSize = 100;
my $type = 'percentage';
my $mappedFlag;
my $smooth = 'move';
my $sort;
my $strandedness;
my $span = 5;
my $verbose;

GetOptions (
  "f|feature=s{1,1}"                 =>\$features,
  "i|input=s{1,1}"                   =>\$input,
  "o|output=s{1,1}"                  =>\$output,
  "s|size=s{1,1}"                    =>\$binSize,
  "t|type=s{1,1}"                    =>\$type,
  "bed12=s{1,1}"                     =>\$bed12File,
  "bed6=s{1,1}"                      =>\$bed6File,
  "binType=s{1,1}"                   =>\$binType,
  "mapped"                           =>\$mappedFlag,
  "smooth=s{1,1}"                    =>\$smooth,
  "span=s{1,1}"                      =>\$span,
  "sort"                             =>\$sort,
  "strand"                           =>\$strandedness,
  "verbose"                          =>\$verbose,
  "h|help"                           =>\$help,
  "man"                              =>\$man
) or pod2usage(2); pod2usage(1) if $help; pod2usage(-verbose => 2) if $man;

if (-f "bedtools") {
  print "bedtools!\n";die;
}else{
  print "bedtools??\n";die;
}

if (defined($verbose)) {
  if (defined($bed12File) and defined($bed6File)) {
    print STDERR "-bed6 will be ignore!\n";
  }
}

if ( ($type ne 'percentage') and ($type ne 'count') ) {
  $type = 'percentage';
  &verbose("Unkown -t. 'percentage' is used!\n");
}

my $outputPath  = &FileFolderPath($output);

my %hashPeak;

my $totalPeak = 1;
my $tempCenter = $outputPath .'/'. rand(1000000) .'_center.tmp';
open (PEAK, "<$input") or die "Cannot open file: $input, $!\n";
open (TEMP, ">$tempCenter") or die "Cannot open file: $tempCenter, $!\n";
while (my $line=<PEAK>) {
  next if ($line =~ /^#/);
  chomp($line);
  my @lineContents = split("\t", $line);
  my $pcStart      = int( ($lineContents[1] + $lineContents[2]) / 2 );
  my $pcEnd        = $pcStart + 1;
  if (scalar(@lineContents) < 6) {
    $lineContents[5] = '+';
  }
  my $peakKey      = join("\t", @lineContents[0..2]) ."\t". $lineContents[5];
  ### judge if the bed peaks contain any duplicates
  if (exists($hashPeak{$peakKey})) {
    next;
  }else{
    $hashPeak{$peakKey}++;
  }
  $lineContents[3] = 'peak='. $totalPeak;
  print TEMP $lineContents[0], "\t", $pcStart, "\t", $pcEnd, "\t", join("\t", @lineContents[3..5]),"\n";
  $totalPeak++;
}
close(PEAK);
close(TEMP);



if (defined($bed12File)) {
  $bed6File = $outputPath .'/'. rand(1000000) .'_bed6.tmp';
  `bed12ToBed6.pl -b $bed12File -o $bed6File`;
}

my %hashBed6;
open(IN,"<$bed6File") or die "can't open $bed6File, $!\n";
while (my $line=<IN>) {
  chomp($line);
  my @lineContents = split ("\t", $line);
  my $start = $lineContents[1];
  my $end = $lineContents[2];
  my ($name, $feature, $order) = split (/\|/, $lineContents[3]);
  $hashBed6{$name}->{$feature}->{'order'}->{$order} = $end - $start;
  $hashBed6{$name}->{$feature}->{'size'} += $end - $start;
}
close(IN);

my @features = split (",", $features);
my %hashFeatureBinSize;
if ($binType ne 'average'){
  if ( $binType ne 'constant' ) {
    $binSize = 100;
    &verbose("Unkown -binType. '100' is used for --size!\n");
  }
  for (my $i = 0; $i < scalar(@features); $i++) {
    $hashFeatureBinSize{$features[$i]} = $binSize;
  }
}else{
  my %hashFeatureSize;
  foreach my $featureName (keys %hashBed6) {
    foreach my $feature (keys %{$hashBed6{$featureName}}) {
      my $eachSize = $hashBed6{$featureName}->{$feature}->{'size'};
      $hashFeatureSize{$feature}->{'count'}++;
      $hashFeatureSize{$feature}->{'sumSize'} += $eachSize;
    }
  }
  my $fullFeatureLength = 0;
  foreach my $feature (@features) {
    my $count = $hashFeatureSize{$feature}->{'count'};
    my $sumSize = $hashFeatureSize{$feature}->{'sumSize'};
    $hashFeatureSize{$feature}->{'average'} = $sumSize / $count;
    $fullFeatureLength += $hashFeatureSize{$feature}->{'average'};
  }

  my $totalBinSize = $binSize * scalar(@features);
  foreach my $feature (@features) {
    my $featureLength = $hashFeatureSize{$feature}->{'average'};
    my $featurePercent = $featureLength / $fullFeatureLength;
    my $eachBinSize = sprintf ("%.0f", $featurePercent * $totalBinSize);
    $hashFeatureBinSize{$feature} = $eachBinSize;
  }
}

my $intersectTemp = $outputPath .'/'. rand(1000000) .'_intersect.tmp';
if (defined($sort)) {
  `sort -t \$'\t' -k 1,1V -k 2,2n $tempCenter -o $tempCenter`;
  `sort -t \$'\t' -k 1,1V -k 2,2n $bed6File -o $bed6File`;
}
if (defined($strandedness)) {
  `bedtools intersect -wb -s -a $tempCenter -b $bed6File > $intersectTemp`;
}else{
  `bedtools intersect -wb -a $tempCenter -b $bed6File > $intersectTemp`;
}


my %hashValidPeak;
my %hashBin;
open(INTERSECT,"<$intersectTemp") or die "can't open $intersectTemp, $!\n";
while (my $line=<INTERSECT>) {
  chomp($line);
  my @lineContents = split ("\t", $line);
  my $pcEnd = $lineContents[2];
  my $pcName = $lineContents[3];
  my $featureStart = $lineContents[7];
  my $featureEnd = $lineContents[8];
  my ($featureName, $feature, $order) = split (/\|/, $lineContents[9]);
  my $featureStrand = $lineContents[11];

  if (!exists($hashValidPeak{$pcName})) {
    $hashValidPeak{$pcName}++;
  }else{
    next;
  }

  my $featureBinSize = $hashFeatureBinSize{$feature};
  my $pcShiftRe = 0; # 1 base
  my $bin; # 1 base
  my $featureTotalSize = $hashBed6{$featureName}->{$feature}->{'size'}; #1 base
  for (my $i = 1; $i <= $order; $i++) {
    if ($i == $order) {
      $pcShiftRe += $pcEnd - $featureStart;
    }else{
      my $featureSize = $hashBed6{$featureName}->{$feature}->{'order'}->{$i};
      $pcShiftRe += $featureSize;
    }
  }

  if ($featureStrand eq '+') {
    $bin = ceil( $pcShiftRe / $featureTotalSize * $featureBinSize );
    $hashBin{'original'}->{$feature}->{$bin}++;
  }else{
    $bin = ceil( ($featureTotalSize - $pcShiftRe + 1)/ $featureTotalSize * $featureBinSize );
    $hashBin{'original'}->{$feature}->{$bin}++;
  }
}
close(INTERSECT);

if (defined($bed12File)) {
  `rm -f $tempCenter $intersectTemp $bed6File`;
}else{
  `rm -f $tempCenter $intersectTemp`;
}

my $totalValidPeak = keys %hashValidPeak;
if (defined($mappedFlag)) {
  $totalPeak = $totalValidPeak;
}else{
  if (defined($verbose)) {
    my $DiscardPeakNum = $totalPeak - $totalValidPeak;
    print STDERR "Discard $DiscardPeakNum peaks which do not appear on blocks from $totalPeak peaks ($input).\n";
  }
}


my $spanWith = 0;
foreach my $feature(@features) {
  my $binShift = $spanWith + 1;
  my $eachBinSize = $hashFeatureBinSize{$feature};
  for (my $i = $binShift; $i < ($binShift + $eachBinSize); $i++){
    my $bin = $i - $binShift + 1;
    if (!exists($hashBin{'original'}->{$feature}->{$bin})) {
      if ($type eq 'percentage') {
        $hashBin{'percentage'}->{$i} = 0;
      }else{
        $hashBin{'count'}->{$i} = 0;
      }
    }else{
      if ($type eq 'percentage') {
        $hashBin{'percentage'}->{$i} = sprintf ("%.3f", ($hashBin{'original'}->{$feature}->{$bin} / $totalPeak) * $eachBinSize);
      }else{
        $hashBin{'count'}->{$i} = $hashBin{'original'}->{$feature}->{$bin};
      }
    }
  }
  $spanWith += $eachBinSize;
}

if ($smooth ne 'no' and $smooth ne 'average' and $smooth ne 'move') {
  $smooth = 'average';
  if (defined($verbose)) {
    print STDERR "Unkown -smooth, 'average' will be assigned!\n";
  }
}

my @ouputValueList;
$spanWith = 1;
foreach my $feature (@features) {
  my @binValueList;
  my $eachBinSize = $hashFeatureBinSize{$feature};
  for (my $i = $spanWith; $i < ($spanWith + $eachBinSize); $i++) {
    if ($type eq 'percentage') {
      push(@binValueList, $hashBin{'percentage'}->{$i});
    }else{
      push(@binValueList, $hashBin{'count'}->{$i});
    }
  }
  if ($smooth eq 'average') {
    push( @ouputValueList, &smoothAverage( \@binValueList, $span ) );
  }elsif($smooth eq 'move'){
    push( @ouputValueList, &smoothMove( \@binValueList, $span ) );
  }else{
    push(@ouputValueList, @binValueList);
  }
  $spanWith += $eachBinSize;
}

open (OUT, ">$output") or die "can't open $output, $!\n";
$spanWith = 0;
foreach my $feature (@features) {
  my $eachBinSize = $hashFeatureBinSize{$feature};
  for (my $i = $spanWith; $i < ($spanWith + $eachBinSize); $i++) {
    print OUT join ("\t", ($feature, $i + 1, $ouputValueList[$i])), "\n";
  }
  $spanWith += $eachBinSize;
}

sub smoothMove{
  my ($valueListRef, $span) = @_;
  $span = int($span);
  my @movingSmoothValList;
  for (my $i = 0; $i < scalar(@$valueListRef); $i++) {
    my $sum         = 0;
    my $movingValue = 0;
    if ($i < ($span - 1)) {
      for (my $j = 0; $j <= $i; $j++) {
        $sum += $$valueListRef[$j];
      }
      $movingValue = $sum / ($i + 1);
    }else{
      for (my $j = ($i - $span + 1); $j < ($i + 1); $j++){
        $sum += $$valueListRef[$j];
      }
      $movingValue = $sum / $span;
    }
    $movingSmoothValList[$i] = $movingValue;
  }
  return @movingSmoothValList;
}

sub smoothAverage{
  my ($valueListRef, $span) = @_;
  $span = ( int($span / 2) == ($span / 2) ) ? int($span) + 1 : int($span); # make the span be odd
  my $hSpan = int($span / 2);
  my $listLength = scalar(@$valueListRef);
  my @SmoothValList;

  for (my $i = 0; $i < $listLength; $i++) {
    my $sum         = 0;
    my $averageValue = 0;
    if ($i < $hSpan) {
      my $tSpan = $i * 2 + 1;
      for (my $j = 0; $j < $tSpan; $j++) {
        $sum += $$valueListRef[$j];
      }
      $averageValue = $sum / $tSpan;
    }elsif ($i >= $hSpan and $i < ($listLength - $hSpan)) {
      for (my $j = ($i - $hSpan); $j < ($i + $hSpan + 1); $j++) {
        $sum += $$valueListRef[$j];
      }
      $averageValue = $sum / $span;
    }else{
      my $tSpan = ($listLength - $i - 1) * 2 + 1;
      for (my $j = ($i - $tSpan); $j < ($listLength - 1); $j++) {
        $sum += $$valueListRef[$j];
      }
      $averageValue = $sum / $tSpan;
    }
    $SmoothValList[$i] = $averageValue;
  }
  return @SmoothValList;
}

sub verbose{
  my $warningText = shift;
  if (defined($verbose)) {
    print STDERR $warningText, "\n";
  }
}

sub FileFolderPath{
  my ($file,undef) = @_;
  my @temp = split (/\/|\\/, $file);
  if (scalar(@temp) == 1) {
    return "./";
  }else{
    splice (@temp, -1 , 1);
    return join ("/", @temp);
  }
}

sub isNumeric {
  my $val = shift;
  my $judge = $val + $val;

  if ($val eq "0") {
    return 1;
  }elsif ($judge eq "0") {
    return 0;
  }else{
    return 1;
  }
}

################# Abbreviations for this script #################
#
# bed6File (4thCol) = $geneID:$geneName:$geneType:$txID:$txName:$txType|cds|1
# pcEnd             = end position of a peak center
# pcShiftRe         = length that a peak center shifts from the bigining of a transcript region (5utr, cds, or 3utr)
#
################# Abbreviations for this script #################

__END__

=head1 NAME

This script is designed for computing the distribution patterns on transcripts
Requere: bedtools, bedCoverage.pl, bed12ToBed6.pl

=head1 CAUTIONS

Defaults: -smooth=(move), --size=(100), -sort=(false), -span=(5), -strand=(false).

=head1 SYNOPSIS

metaGeneAnalysis.pl [options] --input [file] -bed12 [file] -o [file]

 Options:
    -bed12                The annotation bed12 file
    -bed6                 The annotation bed6 file
    -binType              bin type, 'constant' or 'average'
    -mapped               Flag for using mapped peaks instead of total peaks
    -smooth               The smooth method ('no', 'average', or 'move')
    -sort                 Sort bed before using bedtools
    -span                 The span for smooth (int, 5 by default)
    -strand               Only report overlap on the same strand
    -f | --feature        The bin features (5utr,cds,3utr)
    -i | --input          The input bed file
    -o | --output         The The out put file
    -s | --size           The bin size (int or 'average')
    -t | --type           The output type (percentage or count)
    -h | --help           Brief help message
    -verbose              Print more warnings
    -man                  Full documentation

=head1 OPTIONS

=over 4

=item B<-h|--help>

metaGeneAnalysis.pl [options] --input [file] -bed12 [file] -o [file]

=item B<-man>

Prints the manual page and exits.

=back

=head1 DESCRIPTION

B<This program> will compute the distribution patterns on transcripts.

=cut
